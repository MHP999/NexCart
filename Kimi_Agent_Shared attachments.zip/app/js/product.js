document.addEventListener('DOMContentLoaded', () => {
  const id = new URLSearchParams(window.location.search).get('id') || 'SF1001';
  const product = SF.getProduct(id);
  const root = document.querySelector('#product-content');
  if (!product) {
    root.innerHTML = `<div class="empty-state">${SF_UI.icon('package', 40)}<h1>Product not found</h1><p>This item may have been removed from the catalog. Explore the latest products instead.</p><a class="button button-dark" href="shop.html">Back to the marketplace</a></div>`;
    return;
  }
  document.title = `${product.name} | SHAMOD FIREZZ`;
  document.querySelector('meta[name="description"]').content = product.description;
  SF.addRecentlyViewed(product.id);
  const discount = SF.discount(product);
  const gallery = [...new Set([product.image, ...(product.gallery || [])])];
  const wished = SF.getWishlist().includes(product.id);
  const compared = SF.getCompare().includes(product.id);
  const related = [...SF.getProducts().filter(item => item.category === product.category && item.id !== product.id), ...SF.getProducts().filter(item => item.category !== product.category && item.id !== product.id)].slice(0, 4);
  const recent = SF.getRecentlyViewed().filter(item => item.id !== product.id).slice(0, 4);
  const sampleReviews = [
    { name: 'Verified customer', rating: 5, date: '2026-10-21', text: 'Excellent quality and exactly as described. Packaging was careful and delivery was quicker than expected.' },
    { name: 'SHAMOD FIREZZ shopper', rating: Math.max(4, Math.round(product.rating)), date: '2026-09-28', text: 'Very good value for the price. The product details were accurate and the whole ordering experience was straightforward.' }
  ];

  root.innerHTML = `<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><span>/</span><a href="shop.html?category=${SF.slugify(product.category)}">${SF_UI.escapeHTML(product.category)}</a><span>/</span><span>${SF_UI.escapeHTML(product.name)}</span></nav>
    <section class="product-detail" aria-labelledby="product-title">
      <div class="product-gallery"><div class="gallery-thumbs">${gallery.map((image, index) => `<button class="gallery-thumb ${index === 0 ? 'is-active' : ''}" type="button" data-gallery-image="${SF_UI.escapeHTML(image)}" aria-label="View product image ${index + 1}"><img src="${SF_UI.escapeHTML(image)}" alt="" width="76" height="76"></button>`).join('')}</div><div class="gallery-main"><img id="gallery-main-image" src="${SF_UI.escapeHTML(product.image)}" alt="${SF_UI.escapeHTML(product.name)}" width="900" height="900"><div class="product-badges">${discount ? `<span class="badge badge-sale">−${discount}%</span>` : ''}${product.isNew ? '<span class="badge badge-new">NEW</span>' : ''}</div></div></div>
      <div class="product-summary"><span class="product-brand">${SF_UI.escapeHTML(product.brand)} · ${SF_UI.escapeHTML(product.category)}</span><h1 id="product-title">${SF_UI.escapeHTML(product.name)}</h1><div class="summary-rating">${SF_UI.stars(product.rating)}<a href="#reviews">${product.reviews} customer reviews</a></div><div class="summary-price"><strong>${SF.money(product.price)}</strong>${product.originalPrice > product.price ? `<del>${SF.money(product.originalPrice)}</del><span class="badge badge-sale">Save ${SF.money(product.originalPrice - product.price)}</span>` : ''}</div><p class="summary-description">${SF_UI.escapeHTML(product.description)}</p><p class="stock-line ${product.stock < 8 ? 'low' : ''}">${SF_UI.icon('check', 17)} ${product.stock > 0 ? `${product.stock} units in stock${product.stock < 8 ? ' — order soon' : ''}` : 'Currently out of stock'}</p>
        <div class="purchase-row"><div class="quantity-control" aria-label="Quantity selector"><button type="button" id="qty-minus" aria-label="Decrease quantity" ${product.stock === 0 ? 'disabled' : ''}>${SF_UI.icon('minus', 17)}</button><label class="sr-only" for="product-qty">Quantity</label><input id="product-qty" type="number" value="1" min="1" max="${Math.max(1, product.stock)}" ${product.stock === 0 ? 'disabled' : ''}><button type="button" id="qty-plus" aria-label="Increase quantity" ${product.stock === 0 ? 'disabled' : ''}>${SF_UI.icon('plus', 17)}</button></div></div>
        <div class="purchase-buttons"><button class="button button-dark" type="button" data-action="add-cart" data-id="${product.id}" data-qty="1" ${product.stock === 0 ? 'disabled' : ''}>${SF_UI.icon('cart', 19)} Add to cart</button><button class="button button-orange" type="button" data-action="buy-now" data-id="${product.id}" data-qty="1" ${product.stock === 0 ? 'disabled' : ''}>Buy now ${SF_UI.icon('arrow', 18)}</button></div>
        <div class="summary-actions"><button type="button" class="${wished ? 'is-active' : ''}" data-action="wishlist" data-id="${product.id}" aria-pressed="${wished}">${SF_UI.icon('heart', 19)} <span>${wished ? 'Saved to wishlist' : 'Add to wishlist'}</span></button><button type="button" class="${compared ? 'is-active' : ''}" data-action="compare" data-id="${product.id}" aria-pressed="${compared}">${SF_UI.icon('compare', 19)} Add to compare</button></div>
        <div class="product-promises"><div>${SF_UI.icon('truck', 22)} Islandwide tracked delivery</div><div>${SF_UI.icon('shield', 22)} 7-day returns on eligible items</div><div>${SF_UI.icon('package', 22)} Quality checked before dispatch</div><div>${SF_UI.icon('check', 22)} Genuine products & clear warranty</div></div>
      </div>
    </section>
    <section class="product-tabs" aria-label="Product information"><div class="tab-list" role="tablist"><button type="button" role="tab" id="tab-description" aria-controls="panel-description" aria-selected="true">Description</button><button type="button" role="tab" id="tab-specs" aria-controls="panel-specs" aria-selected="false">Specifications</button><button type="button" role="tab" id="tab-reviews" aria-controls="panel-reviews" aria-selected="false">Customer reviews</button></div>
      <div class="tab-panel" id="panel-description" role="tabpanel" aria-labelledby="tab-description"><p>${SF_UI.escapeHTML(product.description)} Every order is checked before dispatch and includes the warranty or return coverage listed for this item. Delivery is available to all districts in Sri Lanka.</p></div>
      <div class="tab-panel" id="panel-specs" role="tabpanel" aria-labelledby="tab-specs" hidden><table class="spec-table"><tbody>${Object.entries(product.specs || {}).map(([key, value]) => `<tr><th>${SF_UI.escapeHTML(key)}</th><td>${SF_UI.escapeHTML(value)}</td></tr>`).join('')}<tr><th>Product ID</th><td>${product.id}</td></tr><tr><th>Brand</th><td>${SF_UI.escapeHTML(product.brand)}</td></tr></tbody></table></div>
      <div class="tab-panel" id="panel-reviews" role="tabpanel" aria-labelledby="tab-reviews" hidden><span id="reviews"></span><div class="product-review-list">${sampleReviews.map(review => `<article class="product-review"><header><h3>${review.name}</h3><time datetime="${review.date}">${SF_UI.formatDate(review.date)}</time></header>${SF_UI.stars(review.rating)}<p>${review.text}</p></article>`).join('')}</div></div>
    </section>
    <section class="section" aria-labelledby="related-title"><div class="section-head"><div><span class="eyebrow">MORE TO EXPLORE</span><h2 id="related-title">Related products.</h2></div><a class="text-link" href="shop.html?category=${SF.slugify(product.category)}">View category →</a></div><div class="product-grid">${related.map(item => SF_UI.productCard(item)).join('')}</div></section>
    ${recent.length ? `<section class="section" aria-labelledby="recent-product-title"><div class="section-head"><div><span class="eyebrow">YOUR BROWSING</span><h2 id="recent-product-title">Recently viewed.</h2></div></div><div class="product-grid">${recent.map(item => SF_UI.productCard(item)).join('')}</div></section>` : ''}`;

  const qtyInput = document.querySelector('#product-qty');
  const syncQty = value => {
    const qty = Math.min(product.stock || 1, Math.max(1, Number(value) || 1));
    qtyInput.value = qty;
    document.querySelectorAll('.purchase-buttons [data-qty]').forEach(button => { button.dataset.qty = qty; });
  };
  document.querySelector('#qty-minus').addEventListener('click', () => syncQty(Number(qtyInput.value) - 1));
  document.querySelector('#qty-plus').addEventListener('click', () => syncQty(Number(qtyInput.value) + 1));
  qtyInput.addEventListener('change', () => syncQty(qtyInput.value));
  document.querySelectorAll('[data-gallery-image]').forEach(button => button.addEventListener('click', () => {
    document.querySelector('#gallery-main-image').src = button.dataset.galleryImage;
    document.querySelectorAll('[data-gallery-image]').forEach(item => item.classList.toggle('is-active', item === button));
  }));
  document.querySelectorAll('[role="tab"]').forEach(tab => tab.addEventListener('click', () => {
    document.querySelectorAll('[role="tab"]').forEach(item => item.setAttribute('aria-selected', String(item === tab)));
    document.querySelectorAll('[role="tabpanel"]').forEach(panel => { panel.hidden = panel.id !== tab.getAttribute('aria-controls'); });
  }));
  window.addEventListener('sf:update', event => {
    if (event.detail.key !== SF.KEYS.wishlist) return;
    const active = SF.getWishlist().includes(product.id);
    const button = document.querySelector('.summary-actions [data-action="wishlist"]');
    if (button) button.querySelector('span').textContent = active ? 'Saved to wishlist' : 'Add to wishlist';
  });
  SF_UI.refreshUI();
});
