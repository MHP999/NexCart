/* SHAMOD FIREZZ seed catalog. Admin changes are persisted separately in LocalStorage. */
window.SF_DATA = {
  categories: [
    { name: 'Electronics', slug: 'electronics', image: 'assets/products/headphones.jpg', description: 'Audio, entertainment and everyday tech' },
    { name: 'Mobile Phones', slug: 'mobile-phones', image: 'assets/products/smartphone.jpg', description: 'Smartphones and tablets' },
    { name: 'Computers & Accessories', slug: 'computers-accessories', image: 'assets/products/laptop.jpg', description: 'Work, create and connect' },
    { name: 'Fashion', slug: 'fashion', image: 'assets/products/sneakers.jpg', description: 'Daily essentials with elevated style' },
    { name: "Men's Clothing", slug: 'mens-clothing', image: 'assets/products/jacket.jpg', description: 'Modern wardrobe foundations' },
    { name: "Women's Clothing", slug: 'womens-clothing', image: 'assets/products/womens-fashion.jpg', description: 'Statement pieces and everyday fits' },
    { name: 'Home & Kitchen', slug: 'home-kitchen', image: 'assets/products/kitchen.jpg', description: 'Considered pieces for better living' },
    { name: 'Beauty & Personal Care', slug: 'beauty-personal-care', image: 'assets/products/beauty.jpg', description: 'Rituals worth looking forward to' },
    { name: 'Sports & Outdoor', slug: 'sports-outdoor', image: 'assets/products/sports.jpg', description: 'Gear for every goal' },
    { name: 'Toys & Kids', slug: 'toys-kids', image: 'assets/products/blocks.jpg', description: 'Curiosity starts here' },
    { name: 'Automotive Accessories', slug: 'automotive-accessories', image: 'assets/products/automotive.jpg', description: 'Care for every journey' },
    { name: 'Gaming Accessories', slug: 'gaming-accessories', image: 'assets/products/gaming.jpg', description: 'Level up your setup' }
  ],
  products: [
    {
      id: 'SF1001', name: 'Auralux Pro Wireless Headphones', brand: 'Auralux', category: 'Electronics',
      price: 24990, originalPrice: 34999, rating: 4.8, reviews: 342, stock: 18, sold: 1240, createdAt: '2026-10-24',
      image: 'assets/products/headphones.jpg', gallery: ['assets/products/headphones.jpg', 'assets/products/speaker.jpg'],
      description: 'Immersive over-ear headphones with active noise cancellation, plush memory-foam cushions and up to 42 hours of listening. Built for focused workdays and late-night playlists.',
      specs: { Connectivity: 'Bluetooth 5.3', Battery: 'Up to 42 hours', 'Noise control': 'Hybrid ANC', Warranty: '12 months' },
      featured: true, flash: true, isNew: true, recommended: true
    },
    {
      id: 'SF1002', name: 'SoundPod Rugged Bluetooth Speaker', brand: 'Auralux', category: 'Electronics',
      price: 18750, originalPrice: 24999, rating: 4.7, reviews: 218, stock: 26, sold: 984, createdAt: '2026-09-12',
      image: 'assets/products/speaker.jpg', gallery: ['assets/products/speaker.jpg', 'assets/products/headphones.jpg'],
      description: 'Room-filling 360-degree sound in a compact, water-resistant body. Pair two speakers for stereo sound and keep the music going from sunrise to sunset.',
      specs: { Output: '30 W', Battery: 'Up to 18 hours', Rating: 'IPX7 water resistant', Warranty: '12 months' },
      featured: true, flash: true, recommended: true
    },
    {
      id: 'SF1003', name: 'Visionix 55-inch 4K Smart TV', brand: 'Visionix', category: 'Electronics',
      price: 189990, originalPrice: 229990, rating: 4.6, reviews: 89, stock: 7, sold: 310, createdAt: '2026-10-16',
      image: 'assets/products/television.jpg', gallery: ['assets/products/television.jpg', 'assets/products/gaming.jpg'],
      description: 'A cinematic 4K UHD display with vivid HDR colour, intuitive streaming and a slim bezel that disappears into your living room.',
      specs: { Display: '55-inch 4K UHD', HDR: 'HDR10+', Audio: 'Dolby Audio', Warranty: '24 months' },
      featured: true, isNew: true, recommended: true
    },
    {
      id: 'SF1004', name: 'Nexara X5 5G Smartphone', brand: 'Nexara', category: 'Mobile Phones',
      price: 164990, originalPrice: 184999, rating: 4.8, reviews: 156, stock: 12, sold: 644, createdAt: '2026-10-25',
      image: 'assets/products/smartphone.jpg', gallery: ['assets/products/smartphone.jpg', 'assets/products/tablet.jpg'],
      description: 'A fast, refined 5G smartphone with a brilliant 120 Hz display, all-day battery and a versatile dual-camera system for crisp shots in any light.',
      specs: { Display: '6.7-inch AMOLED, 120 Hz', Storage: '256 GB', RAM: '12 GB', Camera: '50 MP + 12 MP', Warranty: '12 months' },
      featured: true, flash: true, isNew: true, recommended: true
    },
    {
      id: 'SF1005', name: 'Slate Air 11 Wi-Fi Tablet', brand: 'Slate', category: 'Mobile Phones',
      price: 109500, originalPrice: 129999, rating: 4.5, reviews: 73, stock: 9, sold: 288, createdAt: '2026-10-11',
      image: 'assets/products/tablet.jpg', gallery: ['assets/products/tablet.jpg', 'assets/products/smartphone.jpg'],
      description: 'A lightweight tablet for streaming, sketching and staying productive. The sharp 11-inch display and quad speakers make every session feel cinematic.',
      specs: { Display: '11-inch 2K', Storage: '128 GB', Battery: '8,000 mAh', Connectivity: 'Wi-Fi 6', Warranty: '12 months' },
      isNew: true, recommended: true
    },
    {
      id: 'SF1006', name: 'AeroBook 14 Ultrabook', brand: 'Slate', category: 'Computers & Accessories',
      price: 319990, originalPrice: 359999, rating: 4.9, reviews: 117, stock: 6, sold: 420, createdAt: '2026-10-20',
      image: 'assets/products/laptop.jpg', gallery: ['assets/products/laptop.jpg', 'assets/products/keyboard.jpg'],
      description: 'Powerful performance in a precision aluminium frame. A colour-accurate 14-inch display, silent cooling and long battery life keep serious work moving anywhere.',
      specs: { Processor: '12-core performance CPU', Memory: '16 GB unified memory', Storage: '512 GB SSD', Display: '14-inch 2.2K', Warranty: '24 months' },
      featured: true, isNew: true, recommended: true
    },
    {
      id: 'SF1007', name: 'KeyPro Low-Profile Wireless Keyboard', brand: 'KeyPro', category: 'Computers & Accessories',
      price: 16450, originalPrice: 21990, rating: 4.6, reviews: 204, stock: 31, sold: 815, createdAt: '2026-08-19',
      image: 'assets/products/keyboard.jpg', gallery: ['assets/products/keyboard.jpg', 'assets/products/mouse.jpg'],
      description: 'A slim, quiet wireless keyboard with satisfying low-profile keys, multi-device pairing and a full-size layout designed for effortless daily typing.',
      specs: { Layout: 'Full size, US English', Connection: 'Bluetooth / 2.4 GHz', Devices: 'Up to 3', Battery: 'Up to 6 months' },
      flash: true, recommended: true
    },
    {
      id: 'SF1008', name: 'KeyPro Silent Ergonomic Mouse', brand: 'KeyPro', category: 'Computers & Accessories',
      price: 8990, originalPrice: 12500, rating: 4.5, reviews: 301, stock: 44, sold: 1102, createdAt: '2026-07-04',
      image: 'assets/products/mouse.jpg', gallery: ['assets/products/mouse.jpg', 'assets/products/keyboard.jpg'],
      description: 'An contoured wireless mouse with near-silent clicks, adjustable precision and a comfortable thumb rest for long work sessions.',
      specs: { Connection: '2.4 GHz wireless', DPI: '800–3200 adjustable', Buttons: '6 programmable', Battery: 'Up to 12 months' },
      recommended: true
    },
    {
      id: 'SF1009', name: 'UrbanStep Flux Running Sneakers', brand: 'UrbanStep', category: 'Fashion',
      price: 19990, originalPrice: 27500, rating: 4.7, reviews: 428, stock: 22, sold: 1560, createdAt: '2026-09-28',
      image: 'assets/products/sneakers.jpg', gallery: ['assets/products/sneakers.jpg', 'assets/products/backpack.jpg'],
      description: 'Lightweight everyday trainers with responsive cushioning, breathable engineered mesh and durable grip for commutes, workouts and weekends.',
      specs: { Upper: 'Engineered mesh', Sole: 'High-traction rubber', Cushioning: 'Responsive EVA', Sizes: 'UK 6–11' },
      featured: true, flash: true, recommended: true
    },
    {
      id: 'SF1010', name: 'Northline Commuter Backpack', brand: 'Northline', category: 'Fashion',
      price: 12450, originalPrice: 16900, rating: 4.8, reviews: 265, stock: 35, sold: 922, createdAt: '2026-10-08',
      image: 'assets/products/backpack.jpg', gallery: ['assets/products/backpack.jpg', 'assets/products/sneakers.jpg'],
      description: 'A clean, weather-resistant backpack with a padded 15-inch laptop sleeve, organised interior and hidden security pocket for city days.',
      specs: { Capacity: '22 L', Laptop: 'Fits up to 15 inches', Material: 'Recycled water-resistant shell', Warranty: '12 months' },
      isNew: true, recommended: true
    },
    {
      id: 'SF1011', name: 'Northline Essential Cotton T-Shirt', brand: 'Northline', category: "Men's Clothing",
      price: 6490, originalPrice: 8990, rating: 4.6, reviews: 532, stock: 58, sold: 2140, createdAt: '2026-08-11',
      image: 'assets/products/mens-shirt.jpg', gallery: ['assets/products/mens-shirt.jpg', 'assets/products/jacket.jpg'],
      description: 'A premium-weight crew neck cut from breathable combed cotton. Pre-washed for softness and shaped to hold its clean silhouette wash after wash.',
      specs: { Material: '100% combed cotton', Fit: 'Regular', Weight: '220 GSM', Sizes: 'S–XXL' },
      flash: true, recommended: true
    },
    {
      id: 'SF1012', name: 'Northline Moto Leather Jacket', brand: 'Northline', category: "Men's Clothing",
      price: 24990, originalPrice: 32990, rating: 4.9, reviews: 94, stock: 10, sold: 376, createdAt: '2026-10-18',
      image: 'assets/products/jacket.jpg', gallery: ['assets/products/jacket.jpg', 'assets/products/mens-shirt.jpg'],
      description: 'A modern moto jacket crafted from supple vegan leather, finished with matte hardware and a softly lined interior for effortless year-round layering.',
      specs: { Material: 'Premium vegan leather', Lining: 'Recycled polyester', Fit: 'Tailored', Sizes: 'S–XL' },
      featured: true, isNew: true
    },
    {
      id: 'SF1013', name: 'Velora Scarlet Evening Dress', brand: 'Velora', category: "Women's Clothing",
      price: 21850, originalPrice: 28500, rating: 4.8, reviews: 121, stock: 8, sold: 340, createdAt: '2026-10-22',
      image: 'assets/products/dress.jpg', gallery: ['assets/products/dress.jpg', 'assets/products/womens-fashion.jpg'],
      description: 'A flowing statement dress with a flattering fitted bodice and elegant full-length drape, designed for weddings, celebrations and unforgettable entrances.',
      specs: { Material: 'Soft-touch crepe', Fit: 'Fitted bodice, flowing skirt', Length: 'Full length', Sizes: 'XS–XL' },
      featured: true, isNew: true, recommended: true
    },
    {
      id: 'SF1014', name: 'Velora City Trench Coat', brand: 'Velora', category: "Women's Clothing",
      price: 18990, originalPrice: 24990, rating: 4.7, reviews: 86, stock: 14, sold: 402, createdAt: '2026-09-16',
      image: 'assets/products/womens-fashion.jpg', gallery: ['assets/products/womens-fashion.jpg', 'assets/products/dress.jpg'],
      description: 'A polished, easy-layering trench with a relaxed silhouette and considered tailoring. Made to carry you from weekday appointments to weekend plans.',
      specs: { Material: 'Cotton-rich twill', Fit: 'Relaxed', Closure: 'Belted waist', Sizes: 'XS–XL' },
      recommended: true
    },
    {
      id: 'SF1015', name: 'Casa Cloud Accent Armchair', brand: 'Casa Living', category: 'Home & Kitchen',
      price: 74990, originalPrice: 94990, rating: 4.6, reviews: 47, stock: 5, sold: 132, createdAt: '2026-10-10',
      image: 'assets/products/chair.jpg', gallery: ['assets/products/chair.jpg', 'assets/products/sofa.jpg'],
      description: 'A sculptural accent chair with deep foam cushioning, soft woven upholstery and solid timber legs. A comfortable statement for reading corners and calm living spaces.',
      specs: { Upholstery: 'Woven polyester blend', Frame: 'Solid engineered timber', Assembly: 'Leg attachment only', Warranty: '12 months' },
      isNew: true, recommended: true
    },
    {
      id: 'SF1016', name: 'Casa Haven Three-Seat Sofa', brand: 'Casa Living', category: 'Home & Kitchen',
      price: 189500, originalPrice: 219000, rating: 4.9, reviews: 38, stock: 4, sold: 96, createdAt: '2026-08-29',
      image: 'assets/products/sofa.jpg', gallery: ['assets/products/sofa.jpg', 'assets/products/chair.jpg'],
      description: 'Generous, deep seating with a refined low profile and resilient cushions. Upholstered in durable textured fabric for everyday lounging without compromise.',
      specs: { Seats: '3', Upholstery: 'Textured performance fabric', Frame: 'Kiln-dried timber', Warranty: '24 months' },
      featured: true, recommended: true
    },
    {
      id: 'SF1017', name: 'Luma No. 05 Eau de Parfum', brand: 'Luma', category: 'Beauty & Personal Care',
      price: 21500, originalPrice: 25900, rating: 4.8, reviews: 191, stock: 24, sold: 780, createdAt: '2026-09-06',
      image: 'assets/products/perfume.jpg', gallery: ['assets/products/perfume.jpg', 'assets/products/beauty.jpg'],
      description: 'A luminous floral fragrance layered with bergamot, jasmine and warm sandalwood. Elegant and long-lasting without overwhelming the room.',
      specs: { Size: '100 ml', Concentration: 'Eau de parfum', Notes: 'Bergamot, jasmine, sandalwood', Longevity: '6–8 hours' },
      flash: true, recommended: true
    },
    {
      id: 'SF1018', name: 'Luma Radiance Makeup Collection', brand: 'Luma', category: 'Beauty & Personal Care',
      price: 9850, originalPrice: 13900, rating: 4.5, reviews: 149, stock: 29, sold: 611, createdAt: '2026-10-14',
      image: 'assets/products/makeup.jpg', gallery: ['assets/products/makeup.jpg', 'assets/products/beauty.jpg'],
      description: 'A versatile edit of blendable complexion and eye colours in wearable neutral tones, curated for polished everyday looks and easy evening transitions.',
      specs: { Finish: 'Matte and satin', 'Skin types': 'All skin types', Formula: 'Cruelty free', Includes: '8-piece curated set' },
      isNew: true, flash: true
    },
    {
      id: 'SF1019', name: 'Forge Hex Dumbbell Pair', brand: 'Forge', category: 'Sports & Outdoor',
      price: 32990, originalPrice: 39990, rating: 4.7, reviews: 112, stock: 16, sold: 390, createdAt: '2026-07-18',
      image: 'assets/products/dumbbells.jpg', gallery: ['assets/products/dumbbells.jpg', 'assets/products/sports.jpg'],
      description: 'A balanced pair of rubber-coated hex dumbbells with knurled steel grips. The anti-roll design is ideal for controlled strength training at home.',
      specs: { Weight: '10 kg each', Grip: 'Knurled chrome steel', Coating: 'Low-odour rubber', Includes: '2 dumbbells' },
      recommended: true
    },
    {
      id: 'SF1020', name: 'Forge Adjustable Training Barbell', brand: 'Forge', category: 'Sports & Outdoor',
      price: 54900, originalPrice: 69000, rating: 4.8, reviews: 64, stock: 8, sold: 205, createdAt: '2026-10-03',
      image: 'assets/products/sports.jpg', gallery: ['assets/products/sports.jpg', 'assets/products/dumbbells.jpg'],
      description: 'A durable home-training barbell set with secure locking collars and comfortable grip zones, built for progressive full-body strength sessions.',
      specs: { 'Maximum load': '80 kg', Bar: 'Solid steel', Collars: 'Quick-lock pair', Includes: 'Bar, collars and starter guide' },
      isNew: true, featured: true
    },
    {
      id: 'SF1021', name: 'PlayNation Classic Cabriolet Model', brand: 'PlayNation', category: 'Toys & Kids',
      price: 7990, originalPrice: 10900, rating: 4.7, reviews: 228, stock: 33, sold: 910, createdAt: '2026-09-21',
      image: 'assets/products/toys.jpg', gallery: ['assets/products/toys.jpg', 'assets/products/blocks.jpg'],
      description: 'A beautifully detailed pull-back model car with opening doors and a durable die-cast body, made for collectors and imaginative young drivers alike.',
      specs: { Scale: '1:32', Material: 'Die-cast metal and ABS', Action: 'Pull-back motor', Age: '3+ years' },
      flash: true, recommended: true
    },
    {
      id: 'SF1022', name: 'PlayNation Creative Building Blocks', brand: 'PlayNation', category: 'Toys & Kids',
      price: 8990, originalPrice: 11990, rating: 4.9, reviews: 367, stock: 42, sold: 1340, createdAt: '2026-10-06',
      image: 'assets/products/blocks.jpg', gallery: ['assets/products/blocks.jpg', 'assets/products/toys.jpg'],
      description: 'A colourful 500-piece building set that turns open-ended ideas into towers, vehicles and whole imaginary worlds. Compatible with major block systems.',
      specs: { Pieces: '500', Material: 'Non-toxic ABS', Age: '4+ years', Compatibility: 'Major block brands' },
      featured: true, isNew: true, recommended: true
    },
    {
      id: 'SF1023', name: 'DrivePro Performance Air Filter', brand: 'DrivePro', category: 'Automotive Accessories',
      price: 13450, originalPrice: 17900, rating: 4.5, reviews: 81, stock: 19, sold: 318, createdAt: '2026-08-03',
      image: 'assets/products/automotive.jpg', gallery: ['assets/products/automotive.jpg', 'assets/products/car-interior.jpg'],
      description: 'A washable high-flow replacement air filter engineered for dependable filtration, improved airflow and straightforward maintenance.',
      specs: { Type: 'High-flow panel filter', Material: 'Layered cotton gauze', Service: 'Washable and reusable', Fitment: 'Vehicle-specific; confirm before ordering' },
      recommended: true
    },
    {
      id: 'SF1024', name: 'DrivePro Luxury Seat Organiser', brand: 'DrivePro', category: 'Automotive Accessories',
      price: 9450, originalPrice: 12990, rating: 4.6, reviews: 137, stock: 28, sold: 501, createdAt: '2026-10-01',
      image: 'assets/products/car-interior.jpg', gallery: ['assets/products/car-interior.jpg', 'assets/products/automotive.jpg'],
      description: 'A hard-wearing back-seat organiser with dedicated storage for bottles, tablets and travel essentials, keeping every journey calm and clutter-free.',
      specs: { Material: 'Water-resistant vegan leather', Pockets: '8 compartments', Installation: 'Adjustable universal straps', Cleaning: 'Wipe clean' },
      isNew: true, flash: true
    },
    {
      id: 'SF1025', name: 'GameOne 27-inch 165 Hz Monitor', brand: 'GameOne', category: 'Gaming Accessories',
      price: 89990, originalPrice: 109990, rating: 4.8, reviews: 103, stock: 11, sold: 428, createdAt: '2026-10-23',
      image: 'assets/products/gaming.jpg', gallery: ['assets/products/gaming.jpg', 'assets/products/controller.jpg'],
      description: 'Fast, fluid QHD gaming with a 165 Hz refresh rate, low response time and adaptive sync. An ultra-slim bezel keeps your focus exactly where it belongs.',
      specs: { Display: '27-inch QHD IPS', 'Refresh rate': '165 Hz', Response: '1 ms MPRT', Sync: 'Adaptive Sync', Warranty: '24 months' },
      featured: true, isNew: true, flash: true
    },
    {
      id: 'SF1026', name: 'GameOne Elite Wireless Controller', brand: 'GameOne', category: 'Gaming Accessories',
      price: 21990, originalPrice: 27990, rating: 4.7, reviews: 187, stock: 20, sold: 690, createdAt: '2026-09-09',
      image: 'assets/products/controller.jpg', gallery: ['assets/products/controller.jpg', 'assets/products/gaming.jpg'],
      description: 'A responsive low-latency controller with textured grips, precise analogue sticks and customisable back buttons for long, competitive sessions.',
      specs: { Connection: 'Wireless / USB-C', Battery: 'Up to 20 hours', Compatibility: 'PC and supported consoles', Controls: '2 programmable back buttons' },
      flash: true, recommended: true
    }
  ]
};
