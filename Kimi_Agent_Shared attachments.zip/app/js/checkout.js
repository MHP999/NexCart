document.addEventListener('DOMContentLoaded', () => {
  const root = document.querySelector('#checkout-content');
  const orderId = new URLSearchParams(window.location.search).get('order');
  const districts = ['Colombo', 'Gampaha', 'Kalutara', 'Kandy', 'Matale', 'Nuwara Eliya', 'Galle', 'Matara', 'Hambantota', 'Jaffna', 'Kilinochchi', 'Mannar', 'Vavuniya', 'Mullaitivu', 'Batticaloa', 'Ampara', 'Trincomalee', 'Kurunegala', 'Puttalam', 'Anuradhapura', 'Polonnaruwa', 'Badulla', 'Monaragala', 'Ratnapura', 'Kegalle'];

  function showSuccess(order) {
    root.innerHTML = `<section class="checkout-success"><div class="success-mark">${SF_UI.icon('check', 36)}</div><span class="eyebrow">ORDER CONFIRMED</span><h1>Thank you, ${SF_UI.escapeHTML(order.customer.name.split(' ')[0])}.</h1><p>Your order has been placed successfully. We’ve saved the details in your order history${order.payment !== 'Cash on Delivery' ? ' with payment pending' : ''}.</p><div class="order-id">Order ID: ${order.id}</div><p><strong>${SF.money(order.total)}</strong> · ${SF_UI.escapeHTML(order.payment)}<br>Delivery to ${SF_UI.escapeHTML(order.customer.city)}, ${SF_UI.escapeHTML(order.customer.district)}</p><div class="success-actions"><a class="button button-dark" href="account.html#orders">View order history</a><a class="button button-outline" href="shop.html">Continue shopping</a></div></section>`;
  }

  if (orderId) {
    const order = SF.getOrders().find(item => item.id === orderId);
    if (order) { showSuccess(order); return; }
  }
  if (!SF.getCart().length) {
    root.innerHTML = `<div class="empty-state" style="margin-top:40px">${SF_UI.icon('cart', 42)}<h1>Your cart is empty</h1><p>Add at least one product before starting checkout.</p><a class="button button-orange" href="shop.html">Shop products</a></div>`;
    return;
  }
  const user = SF.currentUser();
  root.innerHTML = `<header class="page-hero" style="margin-top:30px;border-radius:var(--radius-lg);padding-inline:28px"><nav class="breadcrumbs" aria-label="Breadcrumb"><a href="index.html">Home</a><span>/</span><a href="cart.html">Cart</a><span>/</span><span>Checkout</span></nav><h1>Almost yours.</h1><p>Complete your delivery and payment details to place your order.</p></header>
    <form class="checkout-layout" id="checkout-form" novalidate><div><section class="form-section"><div class="form-section-head"><span class="form-section-number">1</span><h2>Contact information</h2></div><div class="form-grid"><div class="form-field full"><label for="full-name">Full name</label><input id="full-name" name="name" autocomplete="name" required minlength="2" value="${SF_UI.escapeHTML(user?.name || '')}" placeholder="Your full name"></div><div class="form-field"><label for="phone">Phone number</label><input id="phone" name="phone" type="tel" autocomplete="tel" required pattern="[0-9 ]{9,16}" value="${SF_UI.escapeHTML(user?.phone || '')}" placeholder="07X XXX XXXX"><small>Used for delivery updates</small></div><div class="form-field"><label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" required value="${SF_UI.escapeHTML(user?.email || '')}" placeholder="you@example.com"></div></div></section>
      <section class="form-section"><div class="form-section-head"><span class="form-section-number">2</span><h2>Delivery address</h2></div><div class="form-grid"><div class="form-field full"><label for="address">Street address</label><textarea id="address" name="address" rows="3" autocomplete="street-address" required minlength="5" placeholder="House number, street and area">${SF_UI.escapeHTML(user?.address || '')}</textarea></div><div class="form-field"><label for="city">City</label><input id="city" name="city" autocomplete="address-level2" required value="${SF_UI.escapeHTML(user?.city || '')}" placeholder="Your city"></div><div class="form-field"><label for="district">District</label><select id="district" name="district" autocomplete="address-level1" required>${districts.map(item => `<option value="${item}" ${(user?.district || 'Colombo') === item ? 'selected' : ''}>${item}</option>`).join('')}</select></div></div></section>
      <section class="form-section"><div class="form-section-head"><span class="form-section-number">3</span><h2>Payment method</h2></div><div class="payment-options"><label class="payment-option"><input type="radio" name="payment" value="Cash on Delivery" checked><span><b>Cash on Delivery</b><small>Pay in cash when your order arrives.</small></span></label><label class="payment-option"><input type="radio" name="payment" value="Bank Transfer"><span><b>Bank Transfer</b><small>Transfer after ordering using the bank details provided.</small></span></label><label class="payment-option"><input type="radio" name="payment" value="Online Payment"><span><b>Online Payment</b><small>Integration-ready demo. No real payment will be charged.</small></span></label></div><div class="payment-detail" id="payment-detail">Pay the total amount to the delivery partner when your order arrives.</div><p class="form-error" id="checkout-error" role="alert"></p></section></div>
      <aside class="order-summary" id="checkout-summary"></aside></form>`;

  function renderSummary() {
    const district = document.querySelector('#district').value;
    const totals = SF.cartTotals(district);
    const cart = SF.getCart();
    document.querySelector('#checkout-summary').innerHTML = `<h2>Your order</h2>${cart.map(item => `<div class="summary-line"><span>${SF_UI.escapeHTML(item.product.name)} × ${item.qty}</span><b>${SF.money(item.product.price * item.qty)}</b></div>`).join('')}<div class="summary-line"><span>Subtotal</span><b>${SF.money(totals.subtotal)}</b></div><div class="summary-line"><span>Delivery to ${SF_UI.escapeHTML(district)}</span><b>${totals.delivery ? SF.money(totals.delivery) : 'FREE'}</b></div><div class="summary-line total"><span>Total</span><b>${SF.money(totals.total)}</b></div><button class="button button-orange button-wide" type="submit" id="place-order">Place order ${SF_UI.icon('arrow', 17)}</button><p class="summary-note">${SF_UI.icon('shield', 17)} By placing this order, you confirm that your delivery details are correct.</p>`;
  }
  document.querySelector('#district').addEventListener('change', renderSummary);
  document.querySelectorAll('input[name="payment"]').forEach(input => input.addEventListener('change', () => {
    const details = {
      'Cash on Delivery': 'Pay the total amount to the delivery partner when your order arrives.',
      'Bank Transfer': 'After ordering, transfer to SHAMOD FIREZZ, Demo Bank 001-234567-89. Use your order ID as the reference. Payment remains pending until confirmed.',
      'Online Payment': 'Demo gateway: your order will be created with payment pending. No card details are collected and no real charge is made.'
    };
    document.querySelector('#payment-detail').textContent = details[input.value];
  }));
  document.querySelector('#checkout-form').addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    const error = document.querySelector('#checkout-error');
    error.textContent = '';
    if (!form.checkValidity()) {
      form.reportValidity();
      error.textContent = 'Please complete all required fields with valid information.';
      return;
    }
    const data = new FormData(form);
    const button = document.querySelector('#place-order');
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span> Placing your order…';
    setTimeout(() => {
      try {
        const order = SF.placeOrder({
          customer: { name: data.get('name').trim(), phone: data.get('phone').trim(), email: data.get('email').trim(), address: data.get('address').trim(), city: data.get('city').trim(), district: data.get('district') },
          payment: data.get('payment')
        });
        history.replaceState(null, '', `checkout.html?order=${encodeURIComponent(order.id)}`);
        showSuccess(order);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch (exception) {
        error.textContent = exception.message;
        button.disabled = false;
        button.innerHTML = `Place order ${SF_UI.icon('arrow', 17)}`;
      }
    }, 650);
  });
  renderSummary();
});
