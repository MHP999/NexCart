/* Browser-local data layer for SHAMOD FIREZZ. No server or real payment processing. */
window.SF = (() => {
  const KEYS = {
    products: 'sf_products_v1', categories: 'sf_categories_v1', cart: 'sf_cart_v1',
    wishlist: 'sf_wishlist_v1', compare: 'sf_compare_v1', recent: 'sf_recent_v1',
    users: 'sf_users_v1', session: 'sf_session_v1', orders: 'sf_orders_v1', newsletter: 'sf_newsletter_v1'
  };
  const clone = value => JSON.parse(JSON.stringify(value));
  const read = (key, fallback) => {
    try {
      const value = localStorage.getItem(key);
      return value === null ? clone(fallback) : JSON.parse(value);
    } catch (error) {
      console.warn('Could not read browser data:', error);
      return clone(fallback);
    }
  };
  const write = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('sf:update', { detail: { key } }));
  };
  const uid = prefix => `${prefix}${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  const money = value => `LKR ${Number(value || 0).toLocaleString('en-LK', { maximumFractionDigits: 0 })}`;
  const discount = product => product.originalPrice > product.price ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;
  const slugify = text => text.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  function getProducts() { return read(KEYS.products, window.SF_DATA.products); }
  function saveProducts(products) { write(KEYS.products, products); }
  function getProduct(id) { return getProducts().find(product => product.id === id); }
  function getCategories() { return read(KEYS.categories, window.SF_DATA.categories); }
  function saveCategories(categories) { write(KEYS.categories, categories); }

  function getCart() {
    const products = getProducts();
    return read(KEYS.cart, []).map(item => {
      const product = products.find(p => p.id === item.id);
      return product ? { ...item, product } : null;
    }).filter(Boolean);
  }
  function cartCount() { return getCart().reduce((sum, item) => sum + item.qty, 0); }
  function addToCart(id, qty = 1) {
    const product = getProduct(id);
    if (!product) return { ok: false, message: 'This product is no longer available.' };
    if (product.stock < 1) return { ok: false, message: 'This product is currently out of stock.' };
    const cart = read(KEYS.cart, []);
    const existing = cart.find(item => item.id === id);
    const nextQty = (existing?.qty || 0) + Number(qty);
    if (nextQty > product.stock) return { ok: false, message: `Only ${product.stock} units are available.` };
    if (existing) existing.qty = nextQty;
    else cart.push({ id, qty: Math.max(1, Number(qty)) });
    write(KEYS.cart, cart);
    return { ok: true, message: `${product.name} added to cart.` };
  }
  function updateCart(id, qty) {
    const product = getProduct(id);
    let cart = read(KEYS.cart, []);
    if (!product || qty <= 0) cart = cart.filter(item => item.id !== id);
    else {
      const item = cart.find(entry => entry.id === id);
      if (item) item.qty = Math.min(Number(qty), product.stock);
    }
    write(KEYS.cart, cart);
  }
  function removeFromCart(id) { write(KEYS.cart, read(KEYS.cart, []).filter(item => item.id !== id)); }
  function clearCart() { write(KEYS.cart, []); }
  function cartTotals(district = '') {
    const cart = getCart();
    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
    const delivery = subtotal === 0 || subtotal >= 50000 ? 0 : (district && district !== 'Colombo' ? 790 : 490);
    return { subtotal, delivery, total: subtotal + delivery, count: cartCount() };
  }

  function getWishlist() { return read(KEYS.wishlist, []); }
  function toggleWishlist(id) {
    let list = getWishlist();
    const added = !list.includes(id);
    list = added ? [...list, id] : list.filter(item => item !== id);
    write(KEYS.wishlist, list);
    return added;
  }
  function getCompare() { return read(KEYS.compare, []); }
  function toggleCompare(id) {
    let list = getCompare();
    if (list.includes(id)) {
      list = list.filter(item => item !== id);
      write(KEYS.compare, list);
      return { ok: true, added: false };
    }
    if (list.length >= 3) return { ok: false, message: 'You can compare up to three products at a time.' };
    write(KEYS.compare, [...list, id]);
    return { ok: true, added: true };
  }
  function clearCompare() { write(KEYS.compare, []); }
  function addRecentlyViewed(id) {
    const recent = [id, ...read(KEYS.recent, []).filter(item => item !== id)].slice(0, 6);
    write(KEYS.recent, recent);
  }
  function getRecentlyViewed() { return read(KEYS.recent, []).map(getProduct).filter(Boolean); }

  async function hashPassword(password) {
    if (window.crypto?.subtle) {
      const bytes = new TextEncoder().encode(password);
      const digest = await crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(digest)).map(byte => byte.toString(16).padStart(2, '0')).join('');
    }
    return btoa(unescape(encodeURIComponent(password)));
  }
  function getUsers() { return read(KEYS.users, []); }
  function currentUser() {
    const id = read(KEYS.session, null);
    return getUsers().find(user => user.id === id) || null;
  }
  async function register({ name, email, phone, password }) {
    const users = getUsers();
    const normalizedEmail = email.trim().toLowerCase();
    if (users.some(user => user.email === normalizedEmail)) throw new Error('An account with this email already exists.');
    const user = {
      id: uid('CU'), name: name.trim(), email: normalizedEmail, phone: phone.trim(),
      passwordHash: await hashPassword(password), address: '', city: '', district: 'Colombo',
      createdAt: new Date().toISOString()
    };
    users.push(user);
    write(KEYS.users, users);
    write(KEYS.session, user.id);
    return user;
  }
  async function login(email, password) {
    const normalizedEmail = email.trim().toLowerCase();
    const user = getUsers().find(item => item.email === normalizedEmail);
    if (!user || user.passwordHash !== await hashPassword(password)) throw new Error('Email or password is incorrect.');
    write(KEYS.session, user.id);
    return user;
  }
  function logout() { write(KEYS.session, null); }
  function updateProfile(updates) {
    const user = currentUser();
    if (!user) throw new Error('Please sign in to update your profile.');
    const users = getUsers().map(item => item.id === user.id ? { ...item, ...updates, email: item.email } : item);
    write(KEYS.users, users);
    return users.find(item => item.id === user.id);
  }

  function getOrders() { return read(KEYS.orders, []); }
  function placeOrder({ customer, payment }) {
    const cart = getCart();
    if (!cart.length) throw new Error('Your cart is empty.');
    const products = getProducts();
    for (const item of cart) {
      const latest = products.find(product => product.id === item.id);
      if (!latest || latest.stock < item.qty) throw new Error(`${item.product.name} does not have enough stock. Please update your cart.`);
    }
    const totals = cartTotals(customer.district);
    const order = {
      id: `SF-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      userId: currentUser()?.id || null,
      customer: clone(customer), items: cart.map(item => ({ id: item.id, name: item.product.name, image: item.product.image, price: item.product.price, qty: item.qty })),
      ...totals, payment, paymentStatus: payment === 'Cash on Delivery' ? 'Due on delivery' : 'Pending payment',
      status: 'Processing', createdAt: new Date().toISOString()
    };
    const updatedProducts = products.map(product => {
      const item = cart.find(entry => entry.id === product.id);
      return item ? { ...product, stock: product.stock - item.qty, sold: (product.sold || 0) + item.qty } : product;
    });
    saveProducts(updatedProducts);
    write(KEYS.orders, [order, ...getOrders()]);
    clearCart();
    return order;
  }
  function updateOrderStatus(id, status) {
    write(KEYS.orders, getOrders().map(order => order.id === id ? { ...order, status } : order));
  }

  function subscribe(email) {
    const list = read(KEYS.newsletter, []);
    const normalized = email.trim().toLowerCase();
    if (!list.includes(normalized)) list.push(normalized);
    write(KEYS.newsletter, list);
  }

  return {
    KEYS, money, discount, slugify, uid,
    getProducts, saveProducts, getProduct, getCategories, saveCategories,
    getCart, cartCount, addToCart, updateCart, removeFromCart, clearCart, cartTotals,
    getWishlist, toggleWishlist, getCompare, toggleCompare, clearCompare,
    addRecentlyViewed, getRecentlyViewed,
    getUsers, currentUser, register, login, logout, updateProfile,
    getOrders, placeOrder, updateOrderStatus, subscribe
  };
})();
