document.addEventListener('DOMContentLoaded', () => {
  const products = SF.getProducts();
  const render = (selector, items) => {
    const target = document.querySelector(selector);
    if (target) target.innerHTML = items.map(product => SF_UI.productCard(product)).join('');
  };

  const categoryGrid = document.querySelector('#category-grid');
  categoryGrid.innerHTML = SF.getCategories().map(category => {
    const count = products.filter(product => product.category === category.name).length;
    return `<a class="category-card" href="shop.html?category=${encodeURIComponent(category.slug)}"><img src="${SF_UI.escapeHTML(category.image)}" alt="${SF_UI.escapeHTML(category.name)}" loading="lazy" width="500" height="400"><div><div><h3>${SF_UI.escapeHTML(category.name)}</h3><p>${count} products · ${SF_UI.escapeHTML(category.description)}</p></div>${SF_UI.icon('arrow', 20)}</div></a>`;
  }).join('');

  render('#flash-grid', products.filter(product => product.flash).sort((a, b) => SF.discount(b) - SF.discount(a)).slice(0, 4));
  render('#best-grid', [...products].sort((a, b) => b.sold - a.sold).slice(0, 4));
  render('#new-grid', [...products].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 4));
  render('#recommended-grid', products.filter(product => product.recommended).slice(0, 8));

  const recent = SF.getRecentlyViewed().slice(0, 4);
  if (recent.length) {
    document.querySelector('#recent-section').hidden = false;
    render('#recent-grid', recent);
  }

  document.querySelectorAll('[data-icon]').forEach(element => { element.innerHTML = SF_UI.icon(element.dataset.icon, 25); });
  ['#review-stars-1', '#review-stars-2', '#review-stars-3'].forEach(selector => { document.querySelector(selector).innerHTML = SF_UI.stars(5); });

  const countdown = document.querySelector('#deal-countdown');
  let deadline = Number(localStorage.getItem('sf_flash_deadline'));
  if (!deadline || deadline <= Date.now()) {
    deadline = Date.now() + 2 * 24 * 60 * 60 * 1000;
    localStorage.setItem('sf_flash_deadline', String(deadline));
  }
  const updateCountdown = () => {
    const remaining = Math.max(0, deadline - Date.now());
    const days = Math.floor(remaining / 86400000);
    const hours = Math.floor(remaining / 3600000) % 24;
    const minutes = Math.floor(remaining / 60000) % 60;
    const seconds = Math.floor(remaining / 1000) % 60;
    countdown.innerHTML = [[days, 'DAYS'], [hours, 'HRS'], [minutes, 'MIN'], [seconds, 'SEC']].map(([value, label], index) => `${index ? '<i>:</i>' : ''}<span>${String(value).padStart(2, '0')}<small>${label}</small></span>`).join('');
  };
  updateCountdown();
  setInterval(updateCountdown, 1000);
  SF_UI.refreshUI();
});
