/* Shared storefront UI, navigation and product interactions. */
window.SF_UI = (() => {
  const icons = {
    search: '<circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.5-3.5"></path>',
    user: '<circle cx="12" cy="8" r="4"></circle><path d="M4 21a8 8 0 0 1 16 0"></path>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"></path>',
    cart: '<path d="M3 3h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21 7H6"></path><circle cx="10" cy="20" r="1"></circle><circle cx="18" cy="20" r="1"></circle>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"></path>',
    close: '<path d="m6 6 12 12M18 6 6 18"></path>',
    chevron: '<path d="m9 18 6-6-6-6"></path>',
    down: '<path d="m6 9 6 6 6-6"></path>',
    arrow: '<path d="M5 12h14m-5-5 5 5-5 5"></path>',
    star: '<path d="m12 2.8 2.8 5.7 6.3.9-4.5 4.4 1 6.2-5.6-3-5.6 3 1-6.2-4.5-4.4 6.3-.9Z"></path>',
    compare: '<path d="M8 3 4 7l4 4M4 7h16M16 21l4-4-4-4m4 4H4"></path>',
    trash: '<path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7m4 4v6m4-6v6"></path>',
    minus: '<path d="M5 12h14"></path>',
    plus: '<path d="M12 5v14M5 12h14"></path>',
    check: '<path d="m5 12 4 4L19 6"></path>',
    info: '<circle cx="12" cy="12" r="9"></circle><path d="M12 11v6m0-10h.01"></path>',
    truck: '<path d="M3 6h11v10H3zm11 4h4l3 3v3h-7z"></path><circle cx="7" cy="18" r="2"></circle><circle cx="18" cy="18" r="2"></circle>',
    shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6Z"></path><path d="m9 12 2 2 4-4"></path>',
    package: '<path d="m4 7 8-4 8 4v10l-8 4-8-4Z"></path><path d="m4 7 8 4 8-4m-8 4v10"></path>',
    filter: '<path d="M4 6h16M7 12h10m-7 6h4"></path>',
    logout: '<path d="M10 4H5v16h5m4-4 4-4-4-4m4 4H9"></path>',
    upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4"></path>',
    edit: '<path d="m4 20 4-1 11-11-3-3L5 16Zm11-13 3 3"></path>',
    box: '<path d="M4 4h16v16H4zM4 9h16M9 9v11"></path>',
    dashboard: '<path d="M4 4h6v7H4zm10 0h6v4h-6zM4 15h6v5H4zm10-2h6v7h-6z"></path>',
    tag: '<path d="M20 13 13 20 4 11V4h7Z"></path><circle cx="8" cy="8" r="1"></circle>',
    eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"></path><circle cx="12" cy="12" r="2.5"></circle>'
  };
  const icon = (name, size = 20, className = '') => `<svg class="icon ${className}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.info}</svg>`;
  const escapeHTML = value => String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
  const formatDate = value => new Intl.DateTimeFormat('en-LK', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(value));

  function stars(rating) {
    return `<span class="rating-stars" aria-label="${rating} out of 5 stars">${Array.from({ length: 5 }, (_, index) => icon('star', 14, index < Math.round(rating) ? 'star-filled' : '')).join('')}<b>${rating.toFixed(1)}</b></span>`;
  }

  function productCard(product, options = {}) {
    const wished = SF.getWishlist().includes(product.id);
    const compared = SF.getCompare().includes(product.id);
    const discount = SF.discount(product);
    return `<article class="product-card ${options.compact ? 'product-card-compact' : ''}" data-product-card="${product.id}">
      <div class="product-media">
        <a href="product.html?id=${encodeURIComponent(product.id)}" aria-label="View ${escapeHTML(product.name)}">
          <img src="${escapeHTML(product.image)}" alt="${escapeHTML(product.name)}" loading="lazy" width="600" height="600">
        </a>
        <div class="product-badges">
          ${discount ? `<span class="badge badge-sale">−${discount}%</span>` : ''}
          ${product.isNew ? '<span class="badge badge-new">NEW</span>' : ''}
        </div>
        <div class="product-actions-top">
          <button class="icon-button ${wished ? 'is-active' : ''}" type="button" data-action="wishlist" data-id="${product.id}" aria-label="${wished ? 'Remove from' : 'Add to'} wishlist" aria-pressed="${wished}">${icon('heart', 18)}</button>
          <button class="icon-button ${compared ? 'is-active' : ''}" type="button" data-action="compare" data-id="${product.id}" aria-label="${compared ? 'Remove from' : 'Add to'} comparison" aria-pressed="${compared}">${icon('compare', 18)}</button>
        </div>
        ${product.stock === 0 ? '<span class="stock-overlay">Out of stock</span>' : ''}
      </div>
      <div class="product-info">
        <span class="product-brand">${escapeHTML(product.brand)}</span>
        <h3><a href="product.html?id=${encodeURIComponent(product.id)}">${escapeHTML(product.name)}</a></h3>
        <div class="product-rating">${stars(product.rating)}<span>(${product.reviews})</span></div>
        <div class="price-row"><strong>${SF.money(product.price)}</strong>${product.originalPrice > product.price ? `<del>${SF.money(product.originalPrice)}</del>` : ''}</div>
        <div class="product-card-actions">
          <button class="button button-dark button-small" type="button" data-action="add-cart" data-id="${product.id}" ${product.stock === 0 ? 'disabled' : ''}>${icon('cart', 17)}<span>Add to cart</span></button>
          <button class="button button-outline button-small buy-button" type="button" data-action="buy-now" data-id="${product.id}" ${product.stock === 0 ? 'disabled' : ''}>Buy now</button>
        </div>
      </div>
    </article>`;
  }

  function headerTemplate() {
    const categories = SF.getCategories();
    const user = SF.currentUser();
    return `<a class="skip-link" href="#main-content">Skip to content</a>
      <div class="announcement"><div class="container announcement-inner"><span>Islandwide delivery · Free shipping over LKR 50,000</span><a href="shop.html?sort=best">Shop best sellers ${icon('arrow', 15)}</a></div></div>
      <header class="site-header" id="top">
        <div class="container header-main">
          <button class="icon-button mobile-menu-trigger" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">${icon('menu', 24)}</button>
          <a class="brand" href="index.html" aria-label="SHAMOD FIREZZ home"><span class="brand-mark">SF</span><span>SHAMOD <b>FIREZZ</b></span></a>
          <form class="search-form" id="global-search" role="search" autocomplete="off">
            <label class="sr-only" for="search-input">Search products</label>
            <input id="search-input" name="q" type="search" placeholder="Search products, brands and categories" aria-expanded="false" aria-controls="search-suggestions">
            <button type="submit" aria-label="Search">${icon('search', 21)}<span>Search</span></button>
            <div class="search-suggestions" id="search-suggestions" hidden></div>
          </form>
          <nav class="header-utilities" aria-label="Account and shopping">
            <a href="account.html" class="utility-link">${icon('user', 22)}<span><small>${user ? 'Hello, ' + escapeHTML(user.name.split(' ')[0]) : 'Welcome'}</small>${user ? 'My account' : 'Sign in'}</span></a>
            <a href="account.html#wishlist" class="utility-link utility-icon" aria-label="Wishlist">${icon('heart', 22)}<span class="counter" id="wishlist-count">0</span></a>
            <a href="cart.html" class="utility-link utility-icon" aria-label="Shopping cart">${icon('cart', 23)}<span class="counter" id="cart-count">0</span></a>
          </nav>
        </div>
        <div class="nav-shell"><div class="container nav-inner">
          <nav class="desktop-nav" aria-label="Main navigation">
            <a href="index.html">Home</a><a href="shop.html">Shop all</a>
            <details class="category-menu"><summary>Categories ${icon('down', 14)}</summary><div class="category-dropdown">${categories.map(category => `<a href="shop.html?category=${encodeURIComponent(category.slug)}">${escapeHTML(category.name)}${icon('chevron', 14)}</a>`).join('')}</div></details>
            <a href="index.html#flash-deals">Flash deals</a><a href="index.html#new-arrivals">New arrivals</a><a href="account.html#orders">Track order</a>
          </nav>
          <a class="nav-promise" href="checkout.html">${icon('shield', 16)} Secure checkout</a>
        </div></div>
      </header>
      <div class="drawer-backdrop" id="drawer-backdrop" hidden></div>
      <aside class="mobile-drawer" id="mobile-menu" aria-label="Mobile navigation" aria-hidden="true">
        <div class="drawer-head"><a class="brand" href="index.html"><span class="brand-mark">SF</span><span>SHAMOD <b>FIREZZ</b></span></a><button class="icon-button" type="button" data-close-drawer aria-label="Close menu">${icon('close', 24)}</button></div>
        <nav><a href="index.html">Home</a><a href="shop.html">Shop all products</a><a href="account.html">My account</a><a href="cart.html">Shopping cart</a><p>Shop by category</p>${categories.map(category => `<a href="shop.html?category=${encodeURIComponent(category.slug)}">${escapeHTML(category.name)}${icon('chevron', 16)}</a>`).join('')}</nav>
      </aside>`;
  }

  function footerTemplate() {
    const categories = SF.getCategories().slice(0, 6);
    return `<footer class="site-footer">
      <div class="container footer-top"><div class="footer-statement"><a class="brand brand-light" href="index.html"><span class="brand-mark">SF</span><span>SHAMOD <b>FIREZZ</b></span></a><h2>Everything you need.<br>One dependable marketplace.</h2><p>Quality products, transparent prices and delivery across Sri Lanka.</p></div>
      <div class="newsletter-block"><span class="eyebrow">THE GOOD STUFF, OCCASIONALLY</span><h3>Offers worth opening.</h3><p>Join for new arrivals, member-only prices and curated finds.</p><form class="newsletter-form" data-newsletter><label class="sr-only" for="footer-email">Email address</label><input id="footer-email" type="email" placeholder="Your email address" required><button class="button button-orange" type="submit">Subscribe ${icon('arrow', 17)}</button></form><small>No spam. Unsubscribe any time.</small></div></div>
      <div class="container footer-links"><div><h3>Shop</h3><a href="shop.html">All products</a><a href="index.html#flash-deals">Flash deals</a><a href="index.html#new-arrivals">New arrivals</a><a href="index.html#best-selling">Best sellers</a></div><div><h3>Categories</h3>${categories.map(category => `<a href="shop.html?category=${encodeURIComponent(category.slug)}">${escapeHTML(category.name)}</a>`).join('')}</div><div><h3>Your account</h3><a href="account.html">Sign in / Register</a><a href="account.html#orders">Order history</a><a href="account.html#wishlist">Wishlist</a><a href="cart.html">Shopping cart</a></div><div><h3>Customer care</h3><a href="index.html#delivery-info">Delivery information</a><a href="index.html#delivery-info">Returns & warranty</a><a href="admin.html">Admin dashboard</a><a href="mailto:hello@shamodfirezz.lk">hello@shamodfirezz.lk</a></div></div>
      <div class="container footer-bottom"><span>© 2026 SHAMOD FIREZZ. All rights reserved.</span><span>Prices in Sri Lankan Rupees (LKR)</span></div>
    </footer>`;
  }

  function toast(message, type = 'success') {
    let region = document.querySelector('.toast-region');
    if (!region) {
      region = document.createElement('div');
      region.className = 'toast-region';
      region.setAttribute('aria-live', 'polite');
      document.body.appendChild(region);
    }
    const item = document.createElement('div');
    item.className = `toast toast-${type}`;
    item.innerHTML = `${icon(type === 'success' ? 'check' : 'info', 19)}<span>${escapeHTML(message)}</span><button type="button" aria-label="Dismiss notification">${icon('close', 16)}</button>`;
    item.querySelector('button').addEventListener('click', () => item.remove());
    region.appendChild(item);
    setTimeout(() => item.remove(), 4200);
  }

  function refreshUI() {
    const accountLink = document.querySelector('.header-utilities .utility-link:first-child');
    if (accountLink) {
      const user = SF.currentUser();
      accountLink.innerHTML = `${icon('user', 22)}<span><small>${user ? 'Hello, ' + escapeHTML(user.name.split(' ')[0]) : 'Welcome'}</small>${user ? 'My account' : 'Sign in'}</span>`;
    }
    document.querySelectorAll('#cart-count').forEach(el => { el.textContent = SF.cartCount(); el.hidden = SF.cartCount() === 0; });
    document.querySelectorAll('#wishlist-count').forEach(el => { el.textContent = SF.getWishlist().length; el.hidden = SF.getWishlist().length === 0; });
    document.querySelectorAll('[data-action="wishlist"]').forEach(button => {
      const active = SF.getWishlist().includes(button.dataset.id);
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', active);
      button.setAttribute('aria-label', `${active ? 'Remove from' : 'Add to'} wishlist`);
    });
    document.querySelectorAll('[data-action="compare"]').forEach(button => {
      const active = SF.getCompare().includes(button.dataset.id);
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', active);
    });
    renderCompareTray();
  }

  function renderCompareTray() {
    const tray = document.querySelector('.compare-tray');
    if (!tray) return;
    const items = SF.getCompare().map(SF.getProduct).filter(Boolean);
    tray.hidden = items.length === 0;
    tray.innerHTML = `<div class="compare-tray-items">${items.map(product => `<img src="${escapeHTML(product.image)}" alt="" title="${escapeHTML(product.name)}">`).join('')}</div><span><b>${items.length}</b> of 3 selected</span><button class="button button-orange button-small" type="button" id="open-compare" ${items.length < 2 ? 'disabled' : ''}>Compare now</button><button class="icon-button" type="button" id="clear-compare" aria-label="Clear comparison">${icon('close', 18)}</button>`;
    tray.querySelector('#open-compare')?.addEventListener('click', openCompareModal);
    tray.querySelector('#clear-compare')?.addEventListener('click', SF.clearCompare);
  }

  function openCompareModal() {
    const products = SF.getCompare().map(SF.getProduct).filter(Boolean);
    if (products.length < 2) return;
    const modal = document.querySelector('#compare-modal');
    const rows = [
      ['Price', p => `<strong>${SF.money(p.price)}</strong>`],
      ['Brand', p => escapeHTML(p.brand)],
      ['Category', p => escapeHTML(p.category)],
      ['Rating', p => `${p.rating} / 5 (${p.reviews} reviews)`],
      ['Availability', p => p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'],
      ['Description', p => escapeHTML(p.description)]
    ];
    modal.innerHTML = `<div class="modal-backdrop" data-close-modal></div><section class="modal-panel compare-panel" role="dialog" aria-modal="true" aria-labelledby="compare-title"><div class="modal-head"><div><span class="eyebrow">SIDE BY SIDE</span><h2 id="compare-title">Compare your shortlist</h2></div><button class="icon-button" type="button" data-close-modal aria-label="Close comparison">${icon('close', 24)}</button></div><div class="table-scroll"><table class="compare-table"><thead><tr><th>Feature</th>${products.map(p => `<th><a href="product.html?id=${p.id}"><img src="${escapeHTML(p.image)}" alt=""><span>${escapeHTML(p.name)}</span></a></th>`).join('')}</tr></thead><tbody>${rows.map(([label, render]) => `<tr><th>${label}</th>${products.map(p => `<td>${render(p)}</td>`).join('')}</tr>`).join('')}<tr><th></th>${products.map(p => `<td><button class="button button-dark button-small" data-action="add-cart" data-id="${p.id}" type="button">Add to cart</button></td>`).join('')}</tr></tbody></table></div></section>`;
    modal.hidden = false;
    document.body.classList.add('modal-open');
    modal.querySelector('[data-close-modal]').focus();
  }

  function closeModal(modal) {
    modal.hidden = true;
    document.body.classList.remove('modal-open');
  }

  function initSearch() {
    const form = document.querySelector('#global-search');
    if (!form) return;
    const input = form.querySelector('input');
    const suggestions = form.querySelector('.search-suggestions');
    const close = () => { suggestions.hidden = true; input.setAttribute('aria-expanded', 'false'); };
    input.addEventListener('input', () => {
      const query = input.value.trim().toLowerCase();
      if (query.length < 2) return close();
      const matches = SF.getProducts().filter(product => `${product.name} ${product.brand} ${product.category}`.toLowerCase().includes(query)).slice(0, 6);
      suggestions.innerHTML = matches.length ? `<p>PRODUCT SUGGESTIONS</p>${matches.map(product => `<a href="product.html?id=${product.id}"><img src="${escapeHTML(product.image)}" alt=""><span><b>${escapeHTML(product.name)}</b><small>${escapeHTML(product.category)}</small></span><strong>${SF.money(product.price)}</strong></a>`).join('')}<button type="submit">See all results for “${escapeHTML(input.value.trim())}” ${icon('arrow', 16)}</button>` : `<div class="no-suggestions">No matches yet. Try “headphones”, “fashion” or “gaming”.</div>`;
      suggestions.hidden = false;
      input.setAttribute('aria-expanded', 'true');
    });
    input.addEventListener('keydown', event => { if (event.key === 'Escape') close(); });
    document.addEventListener('click', event => { if (!form.contains(event.target)) close(); });
    form.addEventListener('submit', event => {
      event.preventDefault();
      const query = input.value.trim();
      if (query) window.location.href = `shop.html?q=${encodeURIComponent(query)}`;
      else input.focus();
    });
  }

  function initDrawer() {
    const trigger = document.querySelector('.mobile-menu-trigger');
    const drawer = document.querySelector('.mobile-drawer');
    const backdrop = document.querySelector('.drawer-backdrop');
    if (!trigger || !drawer) return;
    const open = () => {
      drawer.classList.add('is-open'); drawer.setAttribute('aria-hidden', 'false');
      trigger.setAttribute('aria-expanded', 'true'); backdrop.hidden = false;
      document.body.classList.add('drawer-open'); drawer.querySelector('[data-close-drawer]').focus();
    };
    const close = () => {
      drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden', 'true');
      trigger.setAttribute('aria-expanded', 'false'); backdrop.hidden = true;
      document.body.classList.remove('drawer-open'); trigger.focus();
    };
    trigger.addEventListener('click', open);
    drawer.querySelector('[data-close-drawer]').addEventListener('click', close);
    backdrop.addEventListener('click', close);
    drawer.querySelectorAll('a').forEach(link => link.addEventListener('click', close));
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && drawer.classList.contains('is-open')) close(); });
  }

  function initGlobalActions() {
    document.addEventListener('click', event => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const id = button.dataset.id;
      if (button.dataset.action === 'add-cart') {
        const result = SF.addToCart(id, Number(button.dataset.qty || 1));
        toast(result.message, result.ok ? 'success' : 'info');
      }
      if (button.dataset.action === 'buy-now') {
        const result = SF.addToCart(id, Number(button.dataset.qty || 1));
        if (result.ok) window.location.href = 'checkout.html';
        else toast(result.message, 'info');
      }
      if (button.dataset.action === 'wishlist') {
        const added = SF.toggleWishlist(id);
        toast(added ? 'Saved to your wishlist.' : 'Removed from your wishlist.');
      }
      if (button.dataset.action === 'compare') {
        const result = SF.toggleCompare(id);
        if (!result.ok) toast(result.message, 'info');
        else toast(result.added ? 'Added to comparison.' : 'Removed from comparison.');
      }
    });
    document.querySelectorAll('[data-newsletter]').forEach(form => form.addEventListener('submit', event => {
      event.preventDefault();
      const input = form.querySelector('input[type="email"]');
      if (!input.checkValidity()) return input.reportValidity();
      SF.subscribe(input.value);
      toast('You’re on the list. Welcome to SHAMOD FIREZZ.');
      form.reset();
    }));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') document.querySelectorAll('.modal:not([hidden])').forEach(closeModal);
    });
    document.addEventListener('click', event => {
      const closer = event.target.closest('[data-close-modal]');
      if (closer) closeModal(closer.closest('.modal'));
    });
  }

  function initBackToTop() {
    const button = document.querySelector('.back-to-top');
    if (!button) return;
    window.addEventListener('scroll', () => { button.classList.toggle('is-visible', window.scrollY > 600); }, { passive: true });
    button.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  function init() {
    const header = document.querySelector('#site-header');
    const footer = document.querySelector('#site-footer');
    if (header) header.innerHTML = headerTemplate();
    if (footer) footer.innerHTML = footerTemplate();
    if (!document.querySelector('#compare-modal')) {
      const modal = document.createElement('div'); modal.id = 'compare-modal'; modal.className = 'modal'; modal.hidden = true; document.body.appendChild(modal);
    }
    if (!document.querySelector('.compare-tray') && header) {
      const tray = document.createElement('div'); tray.className = 'compare-tray'; tray.hidden = true; document.body.appendChild(tray);
    }
    if (!document.querySelector('.back-to-top')) {
      const button = document.createElement('button'); button.className = 'back-to-top'; button.type = 'button'; button.setAttribute('aria-label', 'Back to top'); button.innerHTML = icon('arrow', 20); document.body.appendChild(button);
    }
    initSearch(); initDrawer(); initGlobalActions(); initBackToTop(); refreshUI();
    window.addEventListener('sf:update', refreshUI);
    window.addEventListener('storage', refreshUI);
  }

  document.addEventListener('DOMContentLoaded', init);
  return { icon, escapeHTML, stars, productCard, toast, refreshUI, formatDate, openCompareModal };
})();
