document.addEventListener('DOMContentLoaded', () => {
  const content = document.querySelector('#admin-content');
  const nav = document.querySelector('#admin-nav');
  const modal = document.querySelector('#admin-modal');
  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'dashboard' },
    { id: 'products', label: 'Products & inventory', icon: 'box' },
    { id: 'orders', label: 'Orders', icon: 'package' },
    { id: 'categories', label: 'Categories', icon: 'tag' },
    { id: 'customers', label: 'Customers', icon: 'user' }
  ];
  let activeTab = location.hash.slice(1) || 'overview';
  if (!tabs.some(tab => tab.id === activeTab)) activeTab = 'overview';

  nav.innerHTML = tabs.map(tab => `<button type="button" data-admin-tab="${tab.id}" class="${activeTab === tab.id ? 'is-active' : ''}">${SF_UI.icon(tab.icon, 19)} ${tab.label}</button>`).join('');

  function openModal(html, className = '') {
    modal.innerHTML = `<div class="modal-backdrop" data-close-modal></div><section class="modal-panel admin-modal-panel ${className}" role="dialog" aria-modal="true">${html}</section>`;
    modal.hidden = false; document.body.classList.add('modal-open');
    modal.querySelector('button[data-close-modal]')?.focus();
  }
  function closeModal() { modal.hidden = true; document.body.classList.remove('modal-open'); }
  function go(tab) {
    activeTab = tab; history.replaceState(null, '', `admin.html#${tab}`);
    nav.querySelectorAll('button').forEach(button => button.classList.toggle('is-active', button.dataset.adminTab === tab));
    render();
  }

  function renderOverview() {
    const orders = SF.getOrders();
    const products = SF.getProducts();
    const users = SF.getUsers();
    const revenue = orders.filter(order => order.status !== 'Cancelled').reduce((sum, order) => sum + order.total, 0);
    const lowStock = products.filter(product => product.stock < 8).sort((a, b) => a.stock - b.stock).slice(0, 6);
    const topProducts = [...products].sort((a, b) => b.sold - a.sold).slice(0, 5);
    const maxSold = topProducts[0]?.sold || 1;
    content.innerHTML = `<section class="admin-stats"><article class="admin-stat"><div class="admin-stat-head"><span>Total sales</span>${SF_UI.icon('tag', 21)}</div><strong>${SF.money(revenue)}</strong><small>From non-cancelled local orders</small></article><article class="admin-stat"><div class="admin-stat-head"><span>Total orders</span>${SF_UI.icon('package', 21)}</div><strong>${orders.length}</strong><small>${orders.filter(order => order.status === 'Processing').length} awaiting processing</small></article><article class="admin-stat"><div class="admin-stat-head"><span>Total customers</span>${SF_UI.icon('user', 21)}</div><strong>${users.length}</strong><small>Registered in this browser</small></article><article class="admin-stat"><div class="admin-stat-head"><span>Total products</span>${SF_UI.icon('box', 21)}</div><strong>${products.length}</strong><small>${lowStock.length} products low on stock</small></article></section>
      <div class="admin-grid"><section class="admin-panel"><div class="admin-panel-head"><div><h2>Recent orders</h2><p>Latest marketplace activity</p></div><button class="text-link" style="border:0;background:transparent" data-admin-tab="orders">Manage all →</button></div>${orders.length ? `<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead><tbody>${orders.slice(0, 5).map(order => `<tr><td><span class="admin-order-id">${order.id}</span><br><small class="muted">${SF_UI.formatDate(order.createdAt)}</small></td><td>${SF_UI.escapeHTML(order.customer.name)}</td><td><b>${SF.money(order.total)}</b></td><td><span class="status-badge ${['Processing', 'Pending'].includes(order.status) ? 'pending' : ''}">${order.status}</span></td></tr>`).join('')}</tbody></table></div>` : `<div class="admin-empty">No orders yet. Place a test order from the storefront to see live metrics here.</div>`}</section>
      <section class="admin-panel"><div class="admin-panel-head"><div><h2>Best sellers</h2><p>By units sold</p></div></div><div class="sales-bars">${topProducts.map(product => `<div class="sales-bar"><div><span>${SF_UI.escapeHTML(product.name)}</span><span>${product.sold}</span></div><div class="sales-bar-track"><span style="width:${product.sold / maxSold * 100}%"></span></div></div>`).join('')}</div></section></div>
      <div class="admin-grid"><section class="admin-panel"><div class="admin-panel-head"><div><h2>Inventory attention</h2><p>Products below 8 units</p></div><button class="text-link" style="border:0;background:transparent" data-admin-tab="products">Update stock →</button></div><div class="admin-low-stock">${lowStock.map(product => `<div class="low-stock-item"><img src="${SF_UI.escapeHTML(product.image)}" alt=""><span><b>${SF_UI.escapeHTML(product.name)}</b><small class="muted">${product.id}</small></span><strong>${product.stock} left</strong></div>`).join('')}</div></section><section class="admin-panel"><div class="admin-panel-head"><div><h2>Quick actions</h2><p>Manage your marketplace</p></div></div><div style="display:grid;gap:10px"><button class="button button-dark" data-add-product type="button">${SF_UI.icon('plus', 17)} Add a new product</button><button class="button button-outline" data-add-category type="button">${SF_UI.icon('tag', 17)} Create a category</button><a class="button button-outline" href="shop.html">View storefront catalog</a></div></section></div>`;
  }

  function productRows(query = '') {
    const normalized = query.trim().toLowerCase();
    const products = SF.getProducts().filter(product => !normalized || `${product.name} ${product.brand} ${product.id} ${product.category}`.toLowerCase().includes(normalized));
    if (!products.length) return `<tr><td colspan="7"><div class="admin-empty">No products match “${SF_UI.escapeHTML(query)}”.</div></td></tr>`;
    return products.map(product => `<tr><td><div class="admin-product-cell"><img src="${SF_UI.escapeHTML(product.image)}" alt=""><span><b>${SF_UI.escapeHTML(product.name)}</b><small>${product.id}</small></span></div></td><td>${SF_UI.escapeHTML(product.category)}</td><td>${SF_UI.escapeHTML(product.brand)}</td><td><b>${SF.money(product.price)}</b></td><td><label class="sr-only" for="stock-${product.id}">Stock for ${SF_UI.escapeHTML(product.name)}</label><input class="admin-stock-input ${product.stock < 8 ? 'low' : ''}" id="stock-${product.id}" type="number" min="0" value="${product.stock}" data-stock-id="${product.id}"></td><td>${product.sold}</td><td><div class="admin-action-buttons"><a class="icon-button" href="product.html?id=${product.id}" aria-label="View ${SF_UI.escapeHTML(product.name)}">${SF_UI.icon('eye', 17)}</a><button class="icon-button" type="button" data-edit-product="${product.id}" aria-label="Edit ${SF_UI.escapeHTML(product.name)}">${SF_UI.icon('edit', 17)}</button><button class="icon-button delete-action" type="button" data-delete-product="${product.id}" aria-label="Delete ${SF_UI.escapeHTML(product.name)}">${SF_UI.icon('trash', 17)}</button></div></td></tr>`).join('');
  }

  function renderProducts() {
    document.querySelector('#admin-page-title').textContent = 'Products & inventory';
    content.innerHTML = `<div class="admin-toolbar"><div class="admin-search">${SF_UI.icon('search', 18)}<label class="sr-only" for="product-search">Search products</label><input id="product-search" type="search" placeholder="Search name, brand, ID or category"></div><button class="button button-orange" type="button" data-add-product>${SF_UI.icon('plus', 17)} Add new product</button></div><section class="admin-panel"><div class="admin-panel-head"><div><h2>Catalog management</h2><p>Edit details, upload images and update stock directly</p></div><span class="muted" style="font-size:11px">${SF.getProducts().length} products</span></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Product</th><th>Category</th><th>Brand</th><th>Price</th><th>Stock</th><th>Sold</th><th>Actions</th></tr></thead><tbody id="admin-product-rows">${productRows()}</tbody></table></div></section>`;
    document.querySelector('#product-search').addEventListener('input', event => { document.querySelector('#admin-product-rows').innerHTML = productRows(event.target.value); });
  }

  function renderOrders() {
    document.querySelector('#admin-page-title').textContent = 'Order management';
    const orders = SF.getOrders();
    const statuses = ['Processing', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
    content.innerHTML = `<section class="admin-panel"><div class="admin-panel-head"><div><h2>Customer orders</h2><p>Review delivery details and update fulfilment status</p></div><span class="muted" style="font-size:11px">${orders.length} total</span></div>${orders.length ? `<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Payment</th><th>Total</th><th>Status</th></tr></thead><tbody>${orders.map(order => `<tr><td><span class="admin-order-id">${order.id}</span><br><small class="muted">${SF_UI.formatDate(order.createdAt)}</small></td><td><b>${SF_UI.escapeHTML(order.customer.name)}</b><br><small class="muted">${SF_UI.escapeHTML(order.customer.phone)} · ${SF_UI.escapeHTML(order.customer.city)}, ${SF_UI.escapeHTML(order.customer.district)}</small></td><td>${order.items.reduce((sum, item) => sum + item.qty, 0)} items<br><small class="muted">${SF_UI.escapeHTML(order.items[0]?.name || '')}${order.items.length > 1 ? ` +${order.items.length - 1} more` : ''}</small></td><td>${SF_UI.escapeHTML(order.payment)}<br><small class="muted">${SF_UI.escapeHTML(order.paymentStatus)}</small></td><td><b>${SF.money(order.total)}</b></td><td><label class="sr-only" for="status-${order.id}">Status for ${order.id}</label><select class="admin-status-select" id="status-${order.id}" data-order-status="${order.id}">${statuses.map(status => `<option ${order.status === status ? 'selected' : ''}>${status}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div>` : `<div class="admin-empty">${SF_UI.icon('package', 34)}<p>No customer orders yet. Orders placed through checkout will appear here.</p><a class="button button-dark" href="shop.html">Go to storefront</a></div>`}</section>`;
  }

  function renderCategories() {
    document.querySelector('#admin-page-title').textContent = 'Category management';
    const categories = SF.getCategories();
    const products = SF.getProducts();
    content.innerHTML = `<section class="admin-panel"><div class="admin-panel-head"><div><h2>Marketplace categories</h2><p>Create categories or remove those without products</p></div></div><div class="admin-category-grid">${categories.map(category => `<article class="admin-category"><img src="${SF_UI.escapeHTML(category.image)}" alt=""><div><h3>${SF_UI.escapeHTML(category.name)}</h3><p>${products.filter(product => product.category === category.name).length} products</p></div><button class="icon-button" type="button" data-delete-category="${SF_UI.escapeHTML(category.slug)}" aria-label="Delete ${SF_UI.escapeHTML(category.name)}">${SF_UI.icon('trash', 16)}</button></article>`).join('')}<button class="admin-category-add" type="button" data-add-category>${SF_UI.icon('plus', 24)}<b>Add new category</b></button></div></section>`;
  }

  function renderCustomers() {
    document.querySelector('#admin-page-title').textContent = 'Customers';
    const users = SF.getUsers();
    const orders = SF.getOrders();
    content.innerHTML = `<section class="admin-panel"><div class="admin-panel-head"><div><h2>Registered customers</h2><p>Customer profiles stored in this browser</p></div><span class="muted" style="font-size:11px">${users.length} total</span></div>${users.length ? `<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Customer</th><th>Contact</th><th>District</th><th>Orders</th><th>Total spent</th><th>Joined</th></tr></thead><tbody>${users.map(user => { const userOrders = orders.filter(order => order.userId === user.id); return `<tr><td><div class="admin-customer-name"><span class="review-avatar">${SF_UI.escapeHTML(user.name.split(' ').map(part => part[0]).join('').slice(0, 2).toUpperCase())}</span><b>${SF_UI.escapeHTML(user.name)}</b></div></td><td>${SF_UI.escapeHTML(user.email)}<br><small class="muted">${SF_UI.escapeHTML(user.phone)}</small></td><td>${SF_UI.escapeHTML(user.district || 'Not set')}</td><td>${userOrders.length}</td><td><b>${SF.money(userOrders.reduce((sum, order) => sum + order.total, 0))}</b></td><td>${SF_UI.formatDate(user.createdAt)}</td></tr>`; }).join('')}</tbody></table></div>` : `<div class="admin-empty">${SF_UI.icon('user', 34)}<p>No registered customers yet. Create an account from the storefront to see it here.</p><a class="button button-dark" href="account.html">Open customer account page</a></div>`}</section>`;
  }

  function openProductForm(product = null) {
    let uploadedImage = product?.image || '';
    openModal(`<div class="modal-head"><div><span class="eyebrow">CATALOG EDITOR</span><h2>${product ? 'Edit product' : 'Add a new product'}</h2></div><button class="icon-button" type="button" data-close-modal aria-label="Close product editor">${SF_UI.icon('close', 22)}</button></div><form id="admin-product-form" class="admin-product-form"><div class="image-upload"><div class="image-upload-preview" id="image-preview">${uploadedImage ? `<img src="${SF_UI.escapeHTML(uploadedImage)}" alt="Product preview">` : SF_UI.icon('upload', 28)}</div><div><label for="product-image">${SF_UI.icon('upload', 17)} ${product ? 'Replace image' : 'Upload product image'}</label><input id="product-image" type="file" accept="image/jpeg,image/png,image/webp"><p>JPG, PNG or WebP. Large images are resized for browser storage.</p></div></div><div class="form-grid"><div class="form-field full"><label for="admin-name">Product name</label><input id="admin-name" name="name" required minlength="3" value="${SF_UI.escapeHTML(product?.name || '')}"></div><div class="form-field"><label for="admin-brand">Brand</label><input id="admin-brand" name="brand" required value="${SF_UI.escapeHTML(product?.brand || '')}"></div><div class="form-field"><label for="admin-category">Category</label><select id="admin-category" name="category" required>${SF.getCategories().map(category => `<option value="${SF_UI.escapeHTML(category.name)}" ${product?.category === category.name ? 'selected' : ''}>${SF_UI.escapeHTML(category.name)}</option>`).join('')}</select></div><div class="form-field"><label for="admin-price">Current price (LKR)</label><input id="admin-price" name="price" type="number" min="1" required value="${product?.price || ''}"></div><div class="form-field"><label for="admin-original">Original price (LKR)</label><input id="admin-original" name="originalPrice" type="number" min="1" required value="${product?.originalPrice || ''}"></div><div class="form-field"><label for="admin-stock">Available stock</label><input id="admin-stock" name="stock" type="number" min="0" required value="${product?.stock ?? ''}"></div><div class="form-field"><label for="admin-rating">Rating (0–5)</label><input id="admin-rating" name="rating" type="number" min="0" max="5" step="0.1" required value="${product?.rating ?? '4.5'}"></div><div class="form-field full"><label for="admin-description">Description</label><textarea id="admin-description" name="description" rows="4" required minlength="10">${SF_UI.escapeHTML(product?.description || '')}</textarea></div><div class="form-field full"><label for="admin-specs">Specifications <span class="muted">(one “Label: Value” per line)</span></label><textarea id="admin-specs" name="specs" rows="4" placeholder="Warranty: 12 months">${SF_UI.escapeHTML(Object.entries(product?.specs || {}).map(([key, value]) => `${key}: ${value}`).join('\n'))}</textarea></div></div><p class="form-error" id="admin-product-error" role="alert"></p><button class="button button-orange button-wide" type="submit">${product ? 'Save product changes' : 'Add product to catalog'}</button></form>`);
    const form = document.querySelector('#admin-product-form');
    document.querySelector('#product-image').addEventListener('change', async event => {
      const file = event.target.files[0];
      if (!file) return;
      try {
        uploadedImage = await resizeImage(file);
        document.querySelector('#image-preview').innerHTML = `<img src="${uploadedImage}" alt="Product preview">`;
      } catch (error) { document.querySelector('#admin-product-error').textContent = error.message; }
    });
    form.addEventListener('submit', event => {
      event.preventDefault();
      const error = document.querySelector('#admin-product-error');
      error.textContent = '';
      if (!form.checkValidity()) { form.reportValidity(); return; }
      if (!uploadedImage) { error.textContent = 'Please upload a product image.'; return; }
      const data = new FormData(form);
      if (Number(data.get('originalPrice')) < Number(data.get('price'))) { error.textContent = 'Original price must be equal to or greater than the current price.'; return; }
      const specs = {};
      data.get('specs').split('\n').forEach(line => { const index = line.indexOf(':'); if (index > 0) specs[line.slice(0, index).trim()] = line.slice(index + 1).trim(); });
      const saved = {
        id: product?.id || SF.uid('SF'), name: data.get('name').trim(), brand: data.get('brand').trim(), category: data.get('category'),
        price: Number(data.get('price')), originalPrice: Number(data.get('originalPrice')), stock: Number(data.get('stock')),
        rating: Number(data.get('rating')), reviews: product?.reviews || 0, sold: product?.sold || 0,
        createdAt: product?.createdAt || new Date().toISOString(), image: uploadedImage, gallery: [uploadedImage],
        description: data.get('description').trim(), specs, featured: product?.featured || false, flash: product?.flash || false,
        isNew: product ? product.isNew : true, recommended: product?.recommended || false
      };
      const products = SF.getProducts();
      if (product) SF.saveProducts(products.map(item => item.id === product.id ? saved : item));
      else SF.saveProducts([saved, ...products]);
      closeModal(); renderProducts(); SF_UI.toast(product ? 'Product changes saved.' : 'New product added to the catalog.');
    });
  }

  function resizeImage(file) {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith('image/')) return reject(new Error('Please choose a valid image file.'));
      if (file.size > 8 * 1024 * 1024) return reject(new Error('Please choose an image smaller than 8 MB.'));
      const image = new Image();
      const url = URL.createObjectURL(file);
      image.onload = () => {
        const scale = Math.min(1, 720 / Math.max(image.width, image.height));
        const canvas = document.createElement('canvas'); canvas.width = Math.round(image.width * scale); canvas.height = Math.round(image.height * scale);
        canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url); resolve(canvas.toDataURL('image/jpeg', .78));
      };
      image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('This image could not be read.')); };
      image.src = url;
    });
  }

  function openCategoryForm() {
    openModal(`<div class="modal-head"><div><span class="eyebrow">CATEGORY EDITOR</span><h2>Create a category</h2></div><button class="icon-button" type="button" data-close-modal aria-label="Close category editor">${SF_UI.icon('close', 22)}</button></div><form id="admin-category-form" class="auth-form"><div class="form-field"><label for="new-category-name">Category name</label><input id="new-category-name" name="name" required minlength="3" placeholder="e.g. Pet Supplies"></div><div class="form-field"><label for="new-category-description">Short description</label><input id="new-category-description" name="description" required placeholder="What customers will find"></div><div class="form-field"><label for="new-category-image">Image path <span class="muted">(optional)</span></label><input id="new-category-image" name="image" placeholder="assets/products/hero.jpg"><small>Use an existing local image path. New categories default to the promotional image.</small></div><p class="form-error" id="category-error" role="alert"></p><button class="button button-orange" type="submit">Create category</button></form>`);
    const form = document.querySelector('#admin-category-form');
    form.addEventListener('submit', event => {
      event.preventDefault(); if (!form.checkValidity()) { form.reportValidity(); return; }
      const data = new FormData(form); const categories = SF.getCategories(); const slug = SF.slugify(data.get('name'));
      if (categories.some(category => category.slug === slug)) { document.querySelector('#category-error').textContent = 'A category with this name already exists.'; return; }
      categories.push({ name: data.get('name').trim(), slug, description: data.get('description').trim(), image: data.get('image').trim() || 'assets/products/hero.jpg' });
      SF.saveCategories(categories); closeModal(); renderCategories(); SF_UI.toast('Category created.');
    });
  }

  function confirmDeleteProduct(id) {
    const product = SF.getProduct(id); if (!product) return;
    openModal(`<div class="admin-confirm">${SF_UI.icon('trash', 36)}<h2>Delete this product?</h2><p>“${SF_UI.escapeHTML(product.name)}” will be removed from the live catalog. Existing order records will be preserved.</p><div class="admin-confirm-actions"><button class="button button-outline" type="button" data-close-modal>Cancel</button><button class="button button-orange" type="button" id="confirm-product-delete">Delete product</button></div></div>`, 'admin-confirm-panel');
    document.querySelector('#confirm-product-delete').addEventListener('click', () => {
      SF.saveProducts(SF.getProducts().filter(item => item.id !== id)); SF.removeFromCart(id);
      closeModal(); renderProducts(); SF_UI.toast('Product deleted from the catalog.');
    });
  }

  function confirmDeleteCategory(slug) {
    const category = SF.getCategories().find(item => item.slug === slug); if (!category) return;
    const count = SF.getProducts().filter(product => product.category === category.name).length;
    if (count) { SF_UI.toast(`Move or delete ${count} products in this category first.`, 'info'); return; }
    openModal(`<div class="admin-confirm">${SF_UI.icon('trash', 36)}<h2>Delete “${SF_UI.escapeHTML(category.name)}”?</h2><p>This empty category will be removed from the marketplace navigation.</p><div class="admin-confirm-actions"><button class="button button-outline" type="button" data-close-modal>Cancel</button><button class="button button-orange" type="button" id="confirm-category-delete">Delete category</button></div></div>`);
    document.querySelector('#confirm-category-delete').addEventListener('click', () => { SF.saveCategories(SF.getCategories().filter(item => item.slug !== slug)); closeModal(); renderCategories(); SF_UI.toast('Category deleted.'); });
  }

  function render() {
    document.querySelector('#admin-page-title').textContent = tabs.find(tab => tab.id === activeTab)?.label || 'Dashboard';
    if (activeTab === 'overview') renderOverview();
    if (activeTab === 'products') renderProducts();
    if (activeTab === 'orders') renderOrders();
    if (activeTab === 'categories') renderCategories();
    if (activeTab === 'customers') renderCustomers();
  }

  nav.addEventListener('click', event => { const button = event.target.closest('[data-admin-tab]'); if (button) go(button.dataset.adminTab); });
  content.addEventListener('click', event => {
    const tab = event.target.closest('[data-admin-tab]'); if (tab) go(tab.dataset.adminTab);
    if (event.target.closest('[data-add-product]')) openProductForm();
    if (event.target.closest('[data-add-category]')) openCategoryForm();
    const edit = event.target.closest('[data-edit-product]'); if (edit) openProductForm(SF.getProduct(edit.dataset.editProduct));
    const remove = event.target.closest('[data-delete-product]'); if (remove) confirmDeleteProduct(remove.dataset.deleteProduct);
    const category = event.target.closest('[data-delete-category]'); if (category) confirmDeleteCategory(category.dataset.deleteCategory);
  });
  content.addEventListener('change', event => {
    if (event.target.matches('[data-stock-id]')) {
      const stock = Math.max(0, Number(event.target.value) || 0); const id = event.target.dataset.stockId;
      SF.saveProducts(SF.getProducts().map(product => product.id === id ? { ...product, stock } : product));
      event.target.value = stock; event.target.classList.toggle('low', stock < 8); SF_UI.toast('Inventory stock updated.');
    }
    if (event.target.matches('[data-order-status]')) {
      SF.updateOrderStatus(event.target.dataset.orderStatus, event.target.value); SF_UI.toast(`Order marked as ${event.target.value}.`);
    }
  });
  window.addEventListener('hashchange', () => {
    activeTab = location.hash.slice(1) || 'overview';
    nav.querySelectorAll('button').forEach(button => button.classList.toggle('is-active', button.dataset.adminTab === activeTab));
    render();
  });
  render();
});
