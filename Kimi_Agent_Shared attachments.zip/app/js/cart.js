document.addEventListener('DOMContentLoaded', () => {
  const root = document.querySelector('#cart-content');
  let district = 'Colombo';

  function render() {
    const cart = SF.getCart();
    if (!cart.length) {
      root.innerHTML = `<div class="empty-state" style="margin-top:34px">${SF_UI.icon('cart', 42)}<h2>Your cart is ready for a good find.</h2><p>Browse the marketplace and add something you love. Your cart will be saved in this browser.</p><a class="button button-orange" href="shop.html">Explore products ${SF_UI.icon('arrow', 17)}</a></div>`;
      return;
    }
    const totals = SF.cartTotals(district);
    const remaining = Math.max(0, 50000 - totals.subtotal);
    root.innerHTML = `<div class="cart-layout"><section aria-label="Cart items"><div class="cart-list">${cart.map(item => `<article class="cart-item"><a href="product.html?id=${item.id}"><img src="${SF_UI.escapeHTML(item.product.image)}" alt="${SF_UI.escapeHTML(item.product.name)}" width="110" height="110"></a><div class="cart-item-info"><span>${SF_UI.escapeHTML(item.product.brand)}</span><h2><a href="product.html?id=${item.id}">${SF_UI.escapeHTML(item.product.name)}</a></h2><span>${SF.money(item.product.price)} each · ${item.product.stock} available</span><div class="quantity-control"><button type="button" data-cart-qty="${item.qty - 1}" data-id="${item.id}" aria-label="Decrease ${SF_UI.escapeHTML(item.product.name)} quantity">${SF_UI.icon('minus', 15)}</button><label class="sr-only" for="cart-qty-${item.id}">Quantity</label><input id="cart-qty-${item.id}" type="number" min="0" max="${item.product.stock}" value="${item.qty}" data-cart-input data-id="${item.id}"><button type="button" data-cart-qty="${item.qty + 1}" data-id="${item.id}" aria-label="Increase ${SF_UI.escapeHTML(item.product.name)} quantity" ${item.qty >= item.product.stock ? 'disabled' : ''}>${SF_UI.icon('plus', 15)}</button></div></div><div class="cart-item-end"><button type="button" data-remove-item data-id="${item.id}" aria-label="Remove ${SF_UI.escapeHTML(item.product.name)}">${SF_UI.icon('trash', 19)}</button><strong>${SF.money(item.product.price * item.qty)}</strong></div></article>`).join('')}</div><div class="cart-below"><a class="text-link" href="shop.html">← Continue shopping</a><span class="muted">${totals.count} ${totals.count === 1 ? 'item' : 'items'}</span></div></section>
      <aside class="order-summary"><h2>Order summary</h2><div class="free-shipping-progress"><p>${remaining > 0 ? `Add <b>${SF.money(remaining)}</b> more for free delivery.` : '<b>You’ve unlocked free delivery.</b>'}</p><div class="progress-track"><span style="width:${Math.min(100, totals.subtotal / 50000 * 100)}%"></span></div></div><div class="form-field"><label for="cart-district">Delivery district</label><select id="cart-district"><option value="Colombo" ${district === 'Colombo' ? 'selected' : ''}>Colombo — LKR 490</option><option value="Other" ${district === 'Other' ? 'selected' : ''}>Other districts — LKR 790</option></select></div><div class="summary-line"><span>Subtotal</span><b>${SF.money(totals.subtotal)}</b></div><div class="summary-line"><span>Delivery</span><b>${totals.delivery ? SF.money(totals.delivery) : 'FREE'}</b></div><div class="summary-line total"><span>Total</span><b>${SF.money(totals.total)}</b></div><a class="button button-orange button-wide" href="checkout.html">Proceed to checkout ${SF_UI.icon('arrow', 17)}</a><p class="summary-note">${SF_UI.icon('shield', 17)} Taxes included. Delivery is confirmed again at checkout.</p></aside></div>`;
    document.querySelector('#cart-district').addEventListener('change', event => { district = event.target.value; render(); });
  }

  root.addEventListener('click', event => {
    const qtyButton = event.target.closest('[data-cart-qty]');
    if (qtyButton) {
      const qty = Number(qtyButton.dataset.cartQty);
      if (qty <= 0) SF.removeFromCart(qtyButton.dataset.id);
      else SF.updateCart(qtyButton.dataset.id, qty);
      render();
    }
    const remove = event.target.closest('[data-remove-item]');
    if (remove) {
      const product = SF.getProduct(remove.dataset.id);
      SF.removeFromCart(remove.dataset.id);
      SF_UI.toast(`${product?.name || 'Item'} removed from your cart.`);
      render();
    }
  });
  root.addEventListener('change', event => {
    if (event.target.matches('[data-cart-input]')) {
      SF.updateCart(event.target.dataset.id, Number(event.target.value));
      render();
    }
  });
  render();
});
