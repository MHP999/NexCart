document.addEventListener('DOMContentLoaded', () => {
  const root = document.querySelector('#account-content');
  const districts = ['Colombo', 'Gampaha', 'Kalutara', 'Kandy', 'Matale', 'Nuwara Eliya', 'Galle', 'Matara', 'Hambantota', 'Jaffna', 'Kilinochchi', 'Mannar', 'Vavuniya', 'Mullaitivu', 'Batticaloa', 'Ampara', 'Trincomalee', 'Kurunegala', 'Puttalam', 'Anuradhapura', 'Polonnaruwa', 'Badulla', 'Monaragala', 'Ratnapura', 'Kegalle'];
  let activeTab = location.hash.slice(1) || 'overview';

  function orderMarkup(orders) {
    if (!orders.length) return `<div class="empty-state">${SF_UI.icon('package', 36)}<h3>No orders yet</h3><p>Your completed orders will appear here with their items, payment and delivery status.</p><a class="button button-dark" href="shop.html">Start shopping</a></div>`;
    return `<div class="orders-list">${orders.map(order => `<article class="order-card"><div class="order-card-head"><div><small>ORDER ID</small><b>${order.id}</b></div><div><small>PLACED</small><span>${SF_UI.formatDate(order.createdAt)}</span></div><span class="status-badge ${['Processing', 'Pending'].includes(order.status) ? 'pending' : ''}">${SF_UI.escapeHTML(order.status)}</span></div><div class="order-card-body">${order.items.map(item => `<div class="order-product"><img src="${SF_UI.escapeHTML(item.image)}" alt=""><span><b>${SF_UI.escapeHTML(item.name)}</b><small>Qty ${item.qty} · ${SF.money(item.price)}</small></span></div>`).join('')}<div class="order-card-total"><span>${SF_UI.escapeHTML(order.payment)} · ${SF_UI.escapeHTML(order.paymentStatus)}</span><strong>${SF.money(order.total)}</strong></div></div></article>`).join('')}</div>`;
  }

  function renderAuth(mode = 'login') {
    root.innerHTML = `<div class="auth-layout"><section class="auth-intro"><span class="eyebrow">YOUR SHAMOD FIREZZ ACCOUNT</span><h1>Good finds,<br>kept together.</h1><p>Sign in to track orders, manage your details and return to your saved favourites.</p><div class="auth-benefits"><div>${SF_UI.icon('package', 22)}<span>Follow every order from placement to delivery.</span></div><div>${SF_UI.icon('heart', 22)}<span>Keep your wishlist ready for the next shopping day.</span></div><div>${SF_UI.icon('check', 22)}<span>Checkout faster with saved delivery information.</span></div></div></section><section class="auth-forms"><div class="auth-tabs"><button type="button" data-auth-tab="login" class="${mode === 'login' ? 'is-active' : ''}">Sign in</button><button type="button" data-auth-tab="register" class="${mode === 'register' ? 'is-active' : ''}">Create account</button></div>
      ${mode === 'login' ? `<form class="auth-form" id="login-form"><h2>Welcome back.</h2><div class="form-field"><label for="login-email">Email address</label><input id="login-email" name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div><div class="form-field"><label for="login-password">Password</label><input id="login-password" name="password" type="password" autocomplete="current-password" required placeholder="Your password"></div><button class="button button-orange button-wide" type="submit">Sign in ${SF_UI.icon('arrow', 17)}</button><p class="form-error" id="auth-error" role="alert"></p></form>` : `<form class="auth-form" id="register-form"><h2>Create your account.</h2><div class="form-grid"><div class="form-field full"><label for="register-name">Full name</label><input id="register-name" name="name" autocomplete="name" required minlength="2"></div><div class="form-field full"><label for="register-email">Email address</label><input id="register-email" name="email" type="email" autocomplete="email" required></div><div class="form-field full"><label for="register-phone">Phone number</label><input id="register-phone" name="phone" type="tel" autocomplete="tel" required pattern="[0-9 ]{9,16}"></div><div class="form-field"><label for="register-password">Password</label><input id="register-password" name="password" type="password" autocomplete="new-password" required minlength="8"><small>At least 8 characters</small></div><div class="form-field"><label for="register-confirm">Confirm password</label><input id="register-confirm" name="confirm" type="password" autocomplete="new-password" required minlength="8"></div></div><button class="button button-orange button-wide" type="submit">Create account ${SF_UI.icon('arrow', 17)}</button><p class="form-error" id="auth-error" role="alert"></p></form>`}
      <p class="demo-note">Demo account: your information is stored only in this browser using LocalStorage. Do not use a sensitive password.</p></section></div>`;
    root.querySelectorAll('[data-auth-tab]').forEach(button => button.addEventListener('click', () => renderAuth(button.dataset.authTab)));
    const form = root.querySelector('.auth-form');
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const data = new FormData(form);
      const error = document.querySelector('#auth-error');
      error.textContent = '';
      if (!form.checkValidity()) { form.reportValidity(); return; }
      if (mode === 'register' && data.get('password') !== data.get('confirm')) { error.textContent = 'Passwords do not match.'; return; }
      const submit = form.querySelector('[type="submit"]');
      submit.disabled = true; submit.innerHTML = '<span class="loading-spinner"></span> Please wait…';
      try {
        if (mode === 'register') await SF.register({ name: data.get('name'), email: data.get('email'), phone: data.get('phone'), password: data.get('password') });
        else await SF.login(data.get('email'), data.get('password'));
        activeTab = 'overview'; history.replaceState(null, '', 'account.html#overview');
        renderAccount();
        SF_UI.toast(mode === 'register' ? 'Your account is ready.' : 'Welcome back.');
      } catch (exception) {
        error.textContent = exception.message;
        submit.disabled = false; submit.textContent = mode === 'register' ? 'Create account' : 'Sign in';
      }
    });
  }

  function panelMarkup(user) {
    const orders = SF.getOrders().filter(order => order.userId === user.id);
    if (activeTab === 'orders') return `<section class="account-panel"><span class="eyebrow">YOUR PURCHASES</span><h1>Order history.</h1><p>Track previous purchases and their current status.</p>${orderMarkup(orders)}</section>`;
    if (activeTab === 'wishlist') {
      const items = SF.getWishlist().map(SF.getProduct).filter(Boolean);
      return `<section class="account-panel"><span class="eyebrow">SAVED FOR LATER</span><h1>Your wishlist.</h1><p>${items.length} saved ${items.length === 1 ? 'product' : 'products'}, stored in this browser.</p>${items.length ? `<div class="product-grid wishlist-grid">${items.map(product => SF_UI.productCard(product)).join('')}</div>` : `<div class="empty-state">${SF_UI.icon('heart', 36)}<h3>Your wishlist is waiting</h3><p>Select the heart on any product to keep it here.</p><a class="button button-dark" href="shop.html">Find something to love</a></div>`}</section>`;
    }
    if (activeTab === 'profile') return `<section class="account-panel"><span class="eyebrow">YOUR DETAILS</span><h1>Profile & delivery.</h1><p>Keep your contact and delivery information up to date for faster checkout.</p><form class="profile-form" id="profile-form"><div class="form-grid"><div class="form-field"><label for="profile-name">Full name</label><input id="profile-name" name="name" required minlength="2" value="${SF_UI.escapeHTML(user.name)}"></div><div class="form-field"><label for="profile-email">Email</label><input id="profile-email" value="${SF_UI.escapeHTML(user.email)}" disabled><small>Email cannot be changed in this demo.</small></div><div class="form-field"><label for="profile-phone">Phone</label><input id="profile-phone" name="phone" required pattern="[0-9 ]{9,16}" value="${SF_UI.escapeHTML(user.phone)}"></div><div class="form-field"><label for="profile-district">District</label><select id="profile-district" name="district">${districts.map(district => `<option ${user.district === district ? 'selected' : ''}>${district}</option>`).join('')}</select></div><div class="form-field full"><label for="profile-address">Address</label><textarea id="profile-address" name="address" rows="3">${SF_UI.escapeHTML(user.address || '')}</textarea></div><div class="form-field"><label for="profile-city">City</label><input id="profile-city" name="city" value="${SF_UI.escapeHTML(user.city || '')}"></div></div><button class="button button-dark" style="margin-top:18px" type="submit">Save changes</button><p class="form-error" id="profile-message" role="status"></p></form></section>`;
    const spent = orders.reduce((sum, order) => sum + order.total, 0);
    return `<section class="account-panel"><span class="eyebrow">MY ACCOUNT</span><h1>Hello, ${SF_UI.escapeHTML(user.name.split(' ')[0])}.</h1><p>Here’s what’s happening with your shopping.</p><div class="account-stats"><div class="account-stat"><span>Total orders</span><strong>${orders.length}</strong></div><div class="account-stat"><span>Wishlist items</span><strong>${SF.getWishlist().length}</strong></div><div class="account-stat"><span>Order value</span><strong>${SF.money(spent)}</strong></div></div><div class="section-head"><h2 style="font-size:26px">Recent orders</h2><button class="text-link" style="border:0;background:transparent" data-account-tab="orders">View all →</button></div>${orderMarkup(orders.slice(0, 2))}</section>`;
  }

  function renderAccount() {
    const user = SF.currentUser();
    if (!user) { renderAuth(); return; }
    if (!['overview', 'orders', 'wishlist', 'profile'].includes(activeTab)) activeTab = 'overview';
    root.innerHTML = `<div class="account-layout"><nav class="account-nav" aria-label="Account sections"><button type="button" data-account-tab="overview" class="${activeTab === 'overview' ? 'is-active' : ''}">${SF_UI.icon('dashboard', 19)} Overview</button><button type="button" data-account-tab="orders" class="${activeTab === 'orders' ? 'is-active' : ''}">${SF_UI.icon('package', 19)} Orders</button><button type="button" data-account-tab="wishlist" class="${activeTab === 'wishlist' ? 'is-active' : ''}">${SF_UI.icon('heart', 19)} Wishlist</button><button type="button" data-account-tab="profile" class="${activeTab === 'profile' ? 'is-active' : ''}">${SF_UI.icon('user', 19)} Profile</button><button type="button" class="logout-button" id="logout">${SF_UI.icon('logout', 19)} Logout</button></nav><div id="account-panel-root">${panelMarkup(user)}</div></div>`;
    document.querySelector('#logout').addEventListener('click', () => { SF.logout(); activeTab = 'overview'; history.replaceState(null, '', 'account.html'); renderAuth(); SF_UI.toast('You’ve been signed out.'); });
    const profileForm = document.querySelector('#profile-form');
    profileForm?.addEventListener('submit', event => {
      event.preventDefault();
      if (!profileForm.checkValidity()) { profileForm.reportValidity(); return; }
      const data = new FormData(profileForm);
      SF.updateProfile({ name: data.get('name').trim(), phone: data.get('phone').trim(), district: data.get('district'), address: data.get('address').trim(), city: data.get('city').trim() });
      document.querySelector('#profile-message').textContent = 'Profile changes saved in this browser.';
      SF_UI.toast('Your profile has been updated.');
    });
    SF_UI.refreshUI();
  }

  root.addEventListener('click', event => {
    const tab = event.target.closest('[data-account-tab]');
    if (!tab) return;
    activeTab = tab.dataset.accountTab;
    history.replaceState(null, '', `account.html#${activeTab}`);
    renderAccount();
  });
  window.addEventListener('hashchange', () => { activeTab = location.hash.slice(1) || 'overview'; renderAccount(); });
  window.addEventListener('sf:update', event => {
    if (event.detail.key === SF.KEYS.wishlist && SF.currentUser() && activeTab === 'wishlist') renderAccount();
  });
  renderAccount();
});
