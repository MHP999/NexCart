document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const products = SF.getProducts();
  const categories = SF.getCategories();
  const state = {
    q: params.get('q') || '',
    categories: params.get('category') ? [params.get('category')] : [],
    brands: [], min: null, max: null, rating: 0,
    sort: params.get('sort') || 'featured'
  };
  const grid = document.querySelector('#shop-grid');
  const sidebar = document.querySelector('#filter-sidebar');
  const backdrop = document.querySelector('#filter-backdrop');
  document.querySelector('#filter-icon').innerHTML = SF_UI.icon('filter', 18);
  document.querySelector('#sort-products').value = state.sort;
  if (window.matchMedia('(max-width: 900px)').matches) sidebar.setAttribute('aria-hidden', 'true');

  document.querySelector('#category-filters').innerHTML = categories.map(category => {
    const count = products.filter(product => product.category === category.name).length;
    return `<label class="filter-option"><input type="checkbox" name="category" value="${category.slug}" ${state.categories.includes(category.slug) ? 'checked' : ''}> ${SF_UI.escapeHTML(category.name)}<span>${count}</span></label>`;
  }).join('');
  const brands = [...new Set(products.map(product => product.brand))].sort();
  document.querySelector('#brand-filters').innerHTML = brands.map(brand => `<label class="filter-option"><input type="checkbox" name="brand" value="${SF_UI.escapeHTML(brand)}"> ${SF_UI.escapeHTML(brand)}<span>${products.filter(product => product.brand === brand).length}</span></label>`).join('');

  function syncState() {
    state.categories = [...document.querySelectorAll('input[name="category"]:checked')].map(input => input.value);
    state.brands = [...document.querySelectorAll('input[name="brand"]:checked')].map(input => input.value);
    state.rating = Number(document.querySelector('input[name="rating"]:checked')?.value || 0);
    state.sort = document.querySelector('#sort-products').value;
  }

  function filteredProducts() {
    let result = products.filter(product => {
      const matchesQuery = !state.q || `${product.name} ${product.brand} ${product.category} ${product.description}`.toLowerCase().includes(state.q.toLowerCase());
      const matchesCategory = !state.categories.length || state.categories.includes(SF.slugify(product.category));
      const matchesBrand = !state.brands.length || state.brands.includes(product.brand);
      const matchesMin = state.min === null || product.price >= state.min;
      const matchesMax = state.max === null || product.price <= state.max;
      return matchesQuery && matchesCategory && matchesBrand && matchesMin && matchesMax && product.rating >= state.rating;
    });
    const sorters = {
      'price-asc': (a, b) => a.price - b.price,
      'price-desc': (a, b) => b.price - a.price,
      newest: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
      best: (a, b) => b.sold - a.sold,
      rating: (a, b) => b.rating - a.rating,
      featured: (a, b) => Number(b.featured || false) - Number(a.featured || false) || b.sold - a.sold
    };
    return result.sort(sorters[state.sort]);
  }

  function renderActiveFilters() {
    const chips = [];
    if (state.q) chips.push({ type: 'q', label: `Search: ${state.q}` });
    state.categories.forEach(slug => chips.push({ type: 'category', value: slug, label: categories.find(c => c.slug === slug)?.name || slug }));
    state.brands.forEach(brand => chips.push({ type: 'brand', value: brand, label: brand }));
    if (state.min !== null || state.max !== null) chips.push({ type: 'price', label: `${state.min === null ? 'Any' : SF.money(state.min)} – ${state.max === null ? 'Any' : SF.money(state.max)}` });
    if (state.rating) chips.push({ type: 'rating', label: `${state.rating}+ stars` });
    const target = document.querySelector('#active-filters');
    target.innerHTML = chips.map(chip => `<button type="button" class="filter-chip" data-clear="${chip.type}" data-value="${SF_UI.escapeHTML(chip.value || '')}">${SF_UI.escapeHTML(chip.label)} ${SF_UI.icon('close', 13)}</button>`).join('');
  }

  function render() {
    syncState();
    const result = filteredProducts();
    document.querySelector('#result-count').innerHTML = `<b>${result.length}</b> ${result.length === 1 ? 'product' : 'products'} found`;
    grid.innerHTML = result.length ? result.map(product => SF_UI.productCard(product)).join('') : `<div class="empty-state">${SF_UI.icon('search', 36)}<h2>No exact matches</h2><p>Try removing a filter or searching with a broader term. There’s plenty more to discover.</p><button class="button button-dark" type="button" id="empty-reset">Clear all filters</button></div>`;
    document.querySelector('#empty-reset')?.addEventListener('click', resetFilters);
    renderActiveFilters();
    const selectedNames = state.categories.map(slug => categories.find(c => c.slug === slug)?.name).filter(Boolean);
    document.querySelector('#shop-title').textContent = state.q ? `Results for “${state.q}”` : selectedNames.length === 1 ? selectedNames[0] : 'Explore the marketplace.';
    document.querySelector('#shop-description').textContent = state.q ? 'Matching products, brands and categories from across the marketplace.' : selectedNames.length === 1 ? categories.find(c => c.name === selectedNames[0])?.description : 'Search, filter and compare quality products across every category.';
    const url = new URL(window.location.href);
    url.search = '';
    if (state.q) url.searchParams.set('q', state.q);
    if (state.categories.length === 1) url.searchParams.set('category', state.categories[0]);
    if (state.sort !== 'featured') url.searchParams.set('sort', state.sort);
    history.replaceState(null, '', `${url.pathname}${url.search}`);
    SF_UI.refreshUI();
  }

  function resetFilters() {
    state.q = ''; state.min = null; state.max = null;
    document.querySelectorAll('#filter-sidebar input[type="checkbox"]').forEach(input => { input.checked = false; });
    document.querySelector('input[name="rating"][value="0"]').checked = true;
    document.querySelector('#min-price').value = ''; document.querySelector('#max-price').value = '';
    document.querySelector('#sort-products').value = 'featured';
    render();
  }

  function openFilters() {
    sidebar.classList.add('is-open'); sidebar.setAttribute('aria-hidden', 'false'); backdrop.hidden = false;
    document.body.classList.add('drawer-open'); document.querySelector('#close-filters').focus();
  }
  function closeFilters() {
    if (!sidebar.classList.contains('is-open')) return;
    sidebar.classList.remove('is-open'); backdrop.hidden = true; document.body.classList.remove('drawer-open');
    if (window.matchMedia('(max-width: 900px)').matches) sidebar.setAttribute('aria-hidden', 'true');
    document.querySelector('#open-filters').focus();
  }

  document.querySelector('#filter-sidebar').addEventListener('change', event => { if (event.target.type !== 'number') render(); });
  document.querySelector('#sort-products').addEventListener('change', render);
  document.querySelector('#apply-price').addEventListener('click', () => {
    const min = Number(document.querySelector('#min-price').value);
    const max = Number(document.querySelector('#max-price').value);
    state.min = document.querySelector('#min-price').value === '' ? null : Math.max(0, min);
    state.max = document.querySelector('#max-price').value === '' ? null : Math.max(0, max);
    if (state.min !== null && state.max !== null && state.min > state.max) {
      SF_UI.toast('Minimum price cannot be higher than maximum price.', 'info');
      return;
    }
    render();
    if (window.matchMedia('(max-width: 900px)').matches) closeFilters();
  });
  document.querySelector('#reset-filters').addEventListener('click', resetFilters);
  document.querySelector('#active-filters').addEventListener('click', event => {
    const chip = event.target.closest('[data-clear]');
    if (!chip) return;
    const type = chip.dataset.clear;
    if (type === 'q') state.q = '';
    if (type === 'category') document.querySelector(`input[name="category"][value="${CSS.escape(chip.dataset.value)}"]`).checked = false;
    if (type === 'brand') document.querySelector(`input[name="brand"][value="${CSS.escape(chip.dataset.value)}"]`).checked = false;
    if (type === 'rating') document.querySelector('input[name="rating"][value="0"]').checked = true;
    if (type === 'price') { state.min = null; state.max = null; document.querySelector('#min-price').value = ''; document.querySelector('#max-price').value = ''; }
    render();
  });
  document.querySelector('#open-filters').addEventListener('click', openFilters);
  document.querySelector('#close-filters').addEventListener('click', closeFilters);
  backdrop.addEventListener('click', closeFilters);
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeFilters(); });
  render();
});
